# Changelog

This file documents every notable project change.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project follows Semantic Versioning. Pin a tag or commit SHA when
loading `QUALITY.md` into a deployment.

## [0.9.2] (2026-11-24)

### Changed
- Announce the move to `abuzucom/agents-personas` at the top of the
  README. The euler persona continues there under `reviewers/euler/`.
  This repository receives no further changes.

## [0.9.1] (2026-11-15)

### Changed

- Updated the foucault integration pin to v3.8.1. The pinned adapter ships
  one review profile on `minimax-m3.1-flash`.
- Ported the upstream retry into `security-review.yml`. A response that
  fails validation now retries on `retry_case.txt`. That envelope carries
  the allowlisted validator problems in trusted context. The retry
  previously resent the same envelope.
- The pinned script check now covers `.foucault/ci/build_retry_case.py`.

## [0.9.0] (2026-11-13)

### Changed

- Switched the quality review model to `minimax-m3.1-flash`. The foucault
  security review already runs it, and its reports passed the format
  validator on the first attempt.
- Replaced the 120,000-character chunk budget in `ci/build_pr_case.py` with a
  byte budget derived from the model context. The builder counts escaped
  UTF-8 bytes. One byte bounds one token for a byte-level BPE tokenizer. The
  budget reserves the reply, `QUALITY.md`, the chat template, the retry note,
  the PR text, the paths, and the prescan items. One envelope holds up to
  857,216 bytes. Most pull requests now take one model call. The reviewer
  sees every changed file together. Larger pull requests still split into
  chunks.

### Added

- Added `--max-bytes` to `ci/build_pr_case.py`. `--max-chars` keeps its
  character budget.
- Added a size guard to `ci/build_pr_case.py`. The builder measures each
  serialized envelope. An envelope above the model budget fails the build.
- Capped the retry note in `ci/run_review.py` at 50 problems of 300
  characters each, with control characters replaced.

### Removed

- Removed the `DEFAULT_MAX_CHARS` constant. `BuildOptions.max_chars` now
  defaults to `None`, which selects the derived byte budget.

## [0.8.7] (2026-11-13)

### Changed

- Updated the foucault integration pin to v3.7.12. The security review now
  runs `minimax-m3.1-flash`. `kimi-k2.7-code` broke the report format
  contract on every euler review.
- Ported the upstream head fetch credential into `security-review.yml`. The
  same-repository head fetch receives `github.token` through its environment
  alone.
- Ported the upstream `check_compliance_tree.py` changes. The scanner drops
  relative `PATH` entries and takes its process directory from
  `tempfile.gettempdir()`. Named constants replace the encoding thresholds and
  the trusted step schema numbers. The euler v7 action pins and the stdout
  guard stay as documented deviations.

## [0.8.6] (2026-11-13)

### Changed

- Pin `actions/checkout` v7.0.1 and `actions/setup-python` v7.1.0 in the
  immutable compliance workflow. The trusted compliance checker accepts the
  same pins.
- Pin `github/codeql-action` v4.39.3 in the CodeQL workflow.

## [0.8.5] (2026-11-13)

### Fixed

- Compare the QUALITY.md diff report with the merge base instead of the base
  branch tip. A pull request no longer reports policy and eval changes that
  landed on `main` after it branched.
- Keep Dependabot away from `immutable-conflict-check.yml` and
  `requirements-checkers.txt`. The trusted compliance schema rejects any pin
  in them other than the one refreshed from foucault.

### Changed

- Share one step list between the `review` and `fork-review` jobs of
  `quality-review.yml` through a YAML anchor. A step fix now reaches both
  review paths.

## [0.8.4] (2026-11-13)

### Fixed

- Stop the Q11 resource-leak check from blocking released resources. An
  argument to `ExitStack.enter_context`, `enter_async_context`, `push`, or
  `push_async_exit` counts as released. An annotated assignment closed in a
  `finally` block counts as released.
- Warn and skip instead of crashing when `package.json` nests past the
  parser limit or holds a dependency section that is not an object.
- Treat `~~~` fences and long backtick fences as code in the policy and
  prose checks. A fence closes only on its own character at equal or greater
  length.

### Changed

- Drop two operands that could never change a result in the workflow path
  test and the poetry pin check.

## [0.8.3] (2026-11-13)

### Fixed

- Grant the reusable review jobs their permissions from the caller jobs.
  A called workflow can only narrow its caller's grants. The security review
  caller granted only `contents: read`, and the quality review caller lacked
  `actions: read`. GitHub refused both runs at startup.
- Document the caller job permissions for quality review adopters.

### Added

- A contract test that checks every local reusable-workflow caller grants
  the permissions its called jobs request.

## [0.8.2] (2026-11-13)

### Fixed

- Count added lines that start with `++` in the prescan line map. The case
  builder treats `---` and `+++` as file headers only before the first hunk.
- Report a non-string finding `class`, finding `file`, or prescan `id` as a
  validation problem. The response validator no longer raises `TypeError` on
  such model output.
- Read the unreviewed files from the envelope metadata in the
  `check_review_response.py` command line. The command line now rejects the
  same APPROVE reports that the review runner rejects.
- Match the expected eval verdict as a whole token on the final line. A
  verdict named only in the justification no longer passes.
- Report a non-array `findings` value in a live eval as a failure instead of
  a crash.

### Changed

- Share one `load_model_call` between `ci/run_review.py` and
  `eval/run_eval.py`. The review runner now validates the `module:function`
  form. `run_eval.load_model_call` stays importable.
- Name the required positional argument count in `call_model` and drop an
  unreachable binary filter in the case builder.

## [0.8.1] (2026-11-13)

### Fixed

- Pass the foucault pin to the reusable security review through a
  `resolve-pr` job output. GitHub rejects the `env` context in a
  reusable-workflow `with:` block. The rejection failed every security review
  run since 0.8.0.

## [0.8.0] (2026-11-09)

### Added

- Updated the foucault integration pin to v3.7.1 and ported the upstream
  capacity handling, verdict-record dedupe, and pin verification.
- Hardened the review against API-derived checkout refs. The worktree stays
  on the repository's default branch, the base and head arrive as git
  objects, and the reusable workflow pins `model_call_command` to the
  trusted adapter.
- Moved the review implementation into a reusable `security-review.yml`.
  Both execution paths call it as a local reusable workflow.
- Ported the upstream fork review. A fork pull request runs the protected
  `fork-review` path after its author or a maintainer applies the
  `safe-to-review` label and an admin approves the environment gate.
- Ported the upstream compliance runner. `immutable-conflict-check.yml`
  scans every pull request tree with the vendored checker before a fork
  review, and the security review now triggers after it. The vendored
  checker set carries euler's branch-prefix configuration and a hash-pinned
  `requirements-checkers.txt`.

## [0.7.1] (2026-11-09)

### Changed

- Bump `actions/setup-python` to v7.1.0, `actions/upload-artifact` to
  v7.0.2, and `github/codeql-action` to v4.39.1, all pinned by full commit
  SHA.
- Update the workflow contract test pin to `upload-artifact` v7.0.2 in the
  same change.

## [0.7.0] (2026-11-09)

### Added

- Added investigation efficiency and timeout guidance to `QUALITY.md`.
- Added trusted timer metadata and timeout evaluation coverage.

## [0.6.6] (2026-10-28)

### Added

- Record the `abuzucom/infiniteprep` adoption in
  `adopters/infiniteprep.md`.

## [0.6.5] (2026-10-10)

### Added

- Reject review reports with process narration.
- Add a narration evaluation case and regression tests.
- Omit invalid model text after repeated response validation failures.

## [0.6.4] (2026-10-08)

### Fixed

- Validate `quality_ref` as a full commit SHA before workflow checkouts.

## [0.6.3] (2026-10-08)

### Fixed

- Narrow reported evaluator finding classes to strings for mypy.

## [0.6.2] (2026-10-08)

### Fixed

- Isolate review commit fetching and envelope creation in a read-only job.
- Require model jobs to consume the prepared artifact after fork environment
  approval.
- Fetch review commits without checking out untrusted pull request content.
- Reject fork reviews when the fetched pull request head differs from
  `head_sha`.
- Format the quality review workflow contract test for Ruff.

## [0.6.0] (2026-10-08)

### Added

- Added an optional `fork_review` input to the reusable quality review.
- Added a protected fork review job that uses the caller's `fork-review`
  environment and validates `MODEL_API_KEY` before model access.
- Added contract coverage for the same-repository and protected fork paths.
- Clarified that only confirmed defects in the post-change code count as findings.
- Rejected unexpected finding classes in the live golden-corpus evaluator.

## [0.5.1] (2026-10-03)

### Added

- Recorded `abuzucom/xdj-rx3-emu` as an adopter in `adopters/xdj-rx3-emu.md`,
  pinned at commit `b23947068a328c19215f8ade3db7bd2b4bcb05cc`.

## [0.5.0] (2026-10-02)

### Added

- `ci/build_pr_case.py` takes an optional `--max-chunks`, 20 by default.
  Files in chunks past the limit become unreviewed files.
- `quality-review.yml` takes an optional `max_chunks` input, 20 by default.
- `quality_checks.run_checks` takes an optional `parse_failures` list. The
  list receives each path whose parse hits a recursion or memory limit.
- `scripts/quality_checks/parser_limits.py` screens Python and TOML files for
  parser limits in a child process. `quality_checks.find_parser_limit_files`
  runs it.

### Fixed

- `ci/build_pr_case.py` reads changed paths with `git diff -z` and passes
  them as literal pathspecs. A file name with spaces or non-ASCII characters
  no longer hides its patch from the model and the prescan.
- `ci/build_pr_case.py` reads every patch from one `git diff --raw -p` call.
  Malformed output or a count mismatch falls back to one call per file.
- `ci/build_pr_case.py` decodes numstat paths strictly as UTF-8. Non-UTF-8
  paths are skipped and handled through the unreviewed list.
- `ci/build_pr_case.py` verifies that `read_blobs` consumes all output bytes
  from `git cat-file --batch`.
- `scripts/quality_checks/parser_limits.py` narrows exception handling in
  `hits_parser_limit` to `SyntaxError` and `tomllib.TOMLDecodeError`.
- `QUALITY.md` prohibits reporting dismissed prescan candidates and intentional
  documented changes as findings with severity ratings.
- A path that is not valid UTF-8 and a text file with an empty patch become
  unreviewed files.
- The prescan reads head blobs with `git ls-tree` and `git cat-file`. A
  `.gitattributes` `export-ignore` entry in the pull request no longer hides
  files from the prescan.
- `ci/run_review.py` fences the blocking prescan list, the unreviewed list,
  and the validation problems in the PR comment. Each list shows at most 50
  items of at most 300 characters. Control characters in an item become `?`.
- `quality-review.yml` posts a new comment on each review run and populates
  the check run text with the report markdown.
- `ci/call_model.py` writes the provider error body to the job log only. The
  `ModelCallError` message keeps the HTTP status.
- The checkers skip a Python or TOML file that raises `RecursionError` or
  `MemoryError` with a warning. The D5 import scan shares that handling.
- The PR builder screens changed files for parser limits in a child process
  before the checkers run. It removes each failing file from its extracted
  tree and lists the file as unreviewed. The main process parses each file
  once.
- `security-review-pr.yml` trusts a `security-review` check run for dedupe
  only when its summary names a default-branch run of this workflow
  holding a `security-review-head-<sha>` marker artifact. `resolve-pr` gains
  `actions: read`.
- The `security-review-pr.yml` dedupe builds its run URL pattern from
  `github.server_url`. Genuine runs match on GitHub Enterprise Server.
- `security-review-pr.yml` reads the verdict token with `read -r` in place of
  unquoted `set --`.
- Set a 30-minute timeout on the `security-review-pr.yml` `review` job and a
  45-minute timeout on the `quality-review.yml` `review` job.
- `security-review-pr.yml` queues a second run for the same head instead of
  cancelling the review in progress.
- Documented the shared model key risk and the manual settings steps in
  `docs/pr-security-review.md`.
- A quality review that fails or times out before a verdict publishes a
  blocking `quality-review` check run. The model review step stops after 40
  minutes.
- `docs/pr-security-review.md` states that a later spoofed check run with the
  same name overrides the real result. The workflow review ruleset closes the
  override. Requiring the GitHub Actions app does not.

## [0.4.0] (2026-09-30)

### Changed

- Adopted the `abuzucom/rough` ruff baseline at commit
  `b52aa382ebede9efb215e479f48cfb9c0b7a9272`. `ruff.toml` holds the block tier
  and `ruff.warn.toml` the warn tier. `target-version` stays `py311`. The
  baseline replaces the default rules plus the PL and S families.
- `make lint` runs the block tier with `--ignore-noqa`, `ruff format --check`,
  and the warn tier with `--exit-zero`.
- Reformatted the Python sources and tests with `ruff format`.
- `ci/call_model.py` posts over `http.client` with an HTTPS-only URL check in
  place of `urllib.request.urlopen`. New tests cover the request, status, and
  error paths.
- Applied two safe block-tier fixes in `dependencies.py` and a test fixture.

## [0.3.0] (2026-09-30)

### Added

- Added `codeql.yml` for CodeQL scanning of Python and GitHub Actions.
- Added `scheduled-validation.yml` for a weekly `make check`.
- Added `.github/dependabot.yml` for weekly action and lint tool updates.
- Added `make lint` with ruff, mypy, and yamllint pinned by hash in
  `requirements-dev.txt`. The `ci` workflow runs it in a `lint` job.
- Added a Python 3.11, 3.12, and 3.13 matrix to the `ci` checks job.
- Set a 15-minute timeout on the `checks`, `lint`, CodeQL `analyze`, and
  scheduled `validate` jobs.

### Changed

- Moved write permissions to job level in `quality-review-pr.yml` and
  `security-review-pr.yml`.
- Fixed D1 to read hash-format requirement files with line continuations.
- Limited D5 runtime declarations to `requirements.txt` and `pyproject.toml`.
- Fixed ruff and mypy findings in the checker code. Marked the command line
  scripts executable.
- Enabled the ruff pylint (PL) and bandit (S) rule families. Five S603 and
  S310 findings have no code fix. `make lint` fails on them by decision.
- Resolved `git` to an absolute path in `ci/build_pr_case.py`.
- Fixed empty quality review reports. `ci/call_model.py` sends `think: false`
  to Ollama and raises `ModelCallError` on empty model text.

### Deprecated

- `ci.call_model.call_model` takes `options=CallOptions(...)`. The
  `transport`, `profile_path`, and `api_key` parameters still work by position
  or keyword and emit a `DeprecationWarning`.

## [0.2.0] (2026-09-30)

### Added

- Added `.github/workflows/security-review-pr.yml`. The workflow runs the
  `abuzucom/foucault` v3.3.14 security review on pull requests from a pinned
  checkout.
- Added `docs/pr-security-review.md`.
- Recorded the foucault pin in `adopters/README.md` and `README.md`.

## [0.1.0] (2026-09-30)

### Added

- Added `AGENTS.md` as a tailored import of the `abuzucom/agents` policy text
  at commit `5b90aec191deccd474312ca4343ed8e47e83ab06`.
- Added `QUALITY.md` with four review modes, 41 classes, four tiers, hard
  blockers, and the `VERDICT_JSON` schema version 1.
- Added `scripts/check_quality_policy.py` and its tests.
- Added the `Makefile` and the `ci` workflow.
- Added `scripts/check_code_quality.py` with heuristic checkers for Q3, Q5, Q8,
  Q9, Q11, Q13, M1, M11, M12, M13, M16, M17, M18, C3, D1, D2, and D5.
- Added the `eval/` golden corpus with 38 cases and `eval/run_eval.py`.
- Added `scripts/review_report.py` and `scripts/review_envelope.py` for report
  parsing and the review envelope.
- Clarified that Blocking and Escalate findings rate HIGH in File, Piece, and
  Wholesale modes.
- Added the PR quality review: `ci/build_pr_case.py`, `ci/call_model.py`,
  `ci/check_review_response.py`, `ci/run_review.py`, and
  `ci/model_providers.json` with Ollama `kimi-k2.7-code` as the active profile.
- Added the reusable `quality-review` workflow and the `quality-review-pr`
  caller for this repository.
- Added `scripts/quality_diff_report.py` and a `ci` step that fails class or
  tier changes without an eval case.
- Added `docs/pr-quality-review.md` and `adopters/README.md`.
- Rewrote `README.md` around the review contract and the foucault boundary.
