#!/usr/bin/env python3
"""Consistency tests for the eval corpus.

Walk the real case directories under eval/cases/. Verify each expected.json
against the harness contract and against AUDIT.md section 2 headings. A
case that drifts from the contract fails here before the harness runs it.
"""
import importlib.util
import json
import re
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
CASES_DIR = REPO_ROOT / "eval" / "cases"
AUDIT_PATH = REPO_ROOT / "AUDIT.md"
RUN_EVAL_PATH = REPO_ROOT / "eval" / "run_eval.py"
REQUIRED_KEYS = ("mode", "expected_verdict", "expected_classes", "notes")
OTHER_ALLOWED_FILES = {"context.md", "spec.md", "tokens.json"}


def _load_run_eval():
    """Import the harness by path."""
    spec = importlib.util.spec_from_file_location("run_eval", RUN_EVAL_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


run_eval = _load_run_eval()


def load_expected(case_dir: Path) -> dict:
    """Parse the expected.json for one case directory."""
    return json.loads(
        (case_dir / "expected.json").read_text(encoding="utf-8"))


def case_dirs() -> list:
    """Return every case directory under eval/cases/."""
    return sorted(p for p in CASES_DIR.iterdir() if p.is_dir())


class CorpusShapeTest(unittest.TestCase):
    """Every case carries a complete, valid expected.json."""

    def test_every_case_dir_has_expected_json(self):
        for case_dir in case_dirs():
            with self.subTest(case=case_dir.name):
                self.assertTrue((case_dir / "expected.json").is_file())

    def test_every_expected_json_has_required_keys(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            for key in REQUIRED_KEYS:
                with self.subTest(case=case_dir.name, key=key):
                    self.assertIn(key, expected)

    def test_every_mode_is_valid(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            with self.subTest(case=case_dir.name):
                self.assertIn(expected["mode"], run_eval.VALID_MODES)

    def test_every_case_loads_through_the_harness(self):
        for case_dir in case_dirs():
            with self.subTest(case=case_dir.name):
                run_eval.load_case(case_dir)

    def test_every_notes_field_is_a_non_empty_string(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            with self.subTest(case=case_dir.name):
                self.assertIsInstance(expected["notes"], str)
                self.assertTrue(expected["notes"].strip())


class ClassReferenceTest(unittest.TestCase):
    """expected_classes entries name real AUDIT.md section 2 classes."""

    def test_every_expected_class_matches_an_audit_heading(self):
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        headings = set(re.findall(r"^### (2\.\d+)", audit_text, re.MULTILINE))
        self.assertTrue(headings)
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            for entry in expected["expected_classes"]:
                with self.subTest(case=case_dir.name, entry=entry):
                    self.assertIn(entry, headings)


class VerdictShapeTest(unittest.TestCase):
    """expected_verdict matches the section 6 shape for the case mode."""

    def test_pr_mode_verdicts(self):
        prefixes = ("APPROVE", "BLOCK", "NEEDS-HUMAN")
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if expected["mode"] != "PR":
                continue
            with self.subTest(case=case_dir.name):
                self.assertTrue(
                    expected["expected_verdict"].startswith(prefixes))

    def test_file_and_wholesale_mode_verdicts(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if expected["mode"] not in ("File", "Wholesale"):
                continue
            with self.subTest(case=case_dir.name):
                self.assertTrue(
                    expected["expected_verdict"].startswith("RISK"))

    def test_piece_mode_verdicts(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if expected["mode"] != "Piece":
                continue
            with self.subTest(case=case_dir.name):
                self.assertTrue(
                    expected["expected_verdict"].startswith("RISK (partial)"))

    def test_design_spec_mode_verdicts(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if expected["mode"] != "Design-spec":
                continue
            with self.subTest(case=case_dir.name):
                self.assertTrue(
                    expected["expected_verdict"].startswith("CONFORMANCE"))


class ExpectJsonTest(unittest.TestCase):
    """expect_json is absent, false, or exactly true."""

    def test_expect_json_false_is_legal(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if expected.get("expect_json") is False:
                with self.subTest(case=case_dir.name):
                    self.assertIs(expected["expect_json"], False)

    def test_expect_json_true_is_explicit(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if "expect_json" in expected and expected["expect_json"]:
                with self.subTest(case=case_dir.name):
                    self.assertIs(expected["expect_json"], True)


class NonAsciiTest(unittest.TestCase):
    """Fixture bytes stay ASCII unless the case opts out with a reason."""

    def test_fixtures_are_ascii_unless_allowed(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if expected.get("allow_non_ascii"):
                continue
            for path in sorted(case_dir.rglob("*")):
                if not path.is_file() or path.name == "expected.json":
                    continue
                data = path.read_bytes()
                with self.subTest(case=case_dir.name, file=path.name):
                    self.assertTrue(
                        all(byte < 128 for byte in data),
                        f"{path} holds a byte above 127")

    def test_allow_non_ascii_case_carries_fixture_notes(self):
        for case_dir in case_dirs():
            expected = load_expected(case_dir)
            if not expected.get("allow_non_ascii"):
                continue
            with self.subTest(case=case_dir.name):
                notes = expected.get("fixture_notes")
                self.assertIsInstance(notes, str)
                self.assertTrue(notes.strip())


class InputNameTest(unittest.TestCase):
    """Case files use recognized names only."""

    def test_input_file_names_are_recognized(self):
        allowed = set(run_eval.CASE_INPUT_NAMES) | OTHER_ALLOWED_FILES
        allowed.add("expected.json")
        for case_dir in case_dirs():
            for path in sorted(case_dir.rglob("*")):
                if not path.is_file():
                    continue
                with self.subTest(case=case_dir.name, file=path.name):
                    self.assertIn(path.name, allowed)


if __name__ == "__main__":
    unittest.main()
