#!/usr/bin/env python3
"""Structural invariants for AUDIT.md.

Guard the contract the harness and the checkers rely on: section order,
size ceiling, the VERDICT_JSON example, the section 6 verdict tokens, and
the section 5 blocker count. Anti-duplication tests catch a new class that
reuses a surface or phrasing from an existing class.
"""
import difflib
import importlib.util
import json
import re
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
AUDIT_PATH = REPO_ROOT / "AUDIT.md"
RUN_EVAL_PATH = REPO_ROOT / "eval" / "run_eval.py"
AUDIT_CHAR_CEILING = 32768
EXPECTED_SECTIONS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
EXPECTED_BLOCKER_COUNT = 5
OVERLAP_THRESHOLD = 0.8

SURFACE_KEYS = {
    "2.1": "semantics", "2.2": "keyboard", "2.3": "naming", "2.4": "visual",
    "2.5": "forms", "2.6": "motion", "2.7": "dynamic", "2.8": "media",
    "2.9": "pointer", "2.10": "reflow", "2.11": "language", "2.12": "darkpattern",
    "2.13": "device", "2.14": "system", "2.15": "aigen", "2.16": "typography",
    "2.17": "volume", "2.18": "deadend", "2.19": "breakpoint", "2.20": "order",
    "2.21": "stylesheet", "2.22": "locale", "2.23": "theme",
}


def _load_run_eval():
    """Import the harness by path."""
    spec = importlib.util.spec_from_file_location("run_eval", RUN_EVAL_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


run_eval = _load_run_eval()


class AuditPresenceTest(unittest.TestCase):
    """AUDIT.md exists at the repository root."""

    def test_audit_md_exists(self):
        self.assertTrue(AUDIT_PATH.is_file())


class SectionOrderTest(unittest.TestCase):
    """Sections 0 through 9 appear exactly once, in order."""

    def test_sections_are_sorted_and_complete(self):
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        found = [
            int(number)
            for number in re.findall(r"^## (\d+)\.", audit_text, re.MULTILINE)
        ]
        self.assertEqual(found, sorted(found))
        self.assertEqual(found, EXPECTED_SECTIONS)


class SizeCeilingTest(unittest.TestCase):
    """The prompt stays under its character ceiling."""

    def test_audit_md_under_ceiling(self):
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        self.assertLessEqual(len(audit_text), AUDIT_CHAR_CEILING)


class VerdictJsonExampleTest(unittest.TestCase):
    """The section 6 VERDICT_JSON example stays parseable and complete."""

    def _extract_block(self) -> str:
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        match = re.search(r"VERDICT_JSON:\s*(\{[^`]+\})", audit_text)
        self.assertIsNotNone(match)
        return match.group(1)

    def test_example_block_parses(self):
        json.loads(self._extract_block())

    def test_example_block_has_required_keys(self):
        parsed = json.loads(self._extract_block())
        for key in ("mode", "verdict", "findings"):
            with self.subTest(key=key):
                self.assertIn(key, parsed)


class SectionSixTokensTest(unittest.TestCase):
    """Every verdict token named in section 6 is one the pattern accepts."""

    def test_section_six_tokens_match_verdict_pattern(self):
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        start = audit_text.index("## 6.")
        end = audit_text.index("## 7.")
        section_six = audit_text[start:end]
        for token in ("VERDICT", "RISK", "RISK (partial)", "CONFORMANCE"):
            with self.subTest(token=token):
                self.assertIn(token, section_six)
                self.assertIsNotNone(
                    run_eval.VERDICT_LINE_RE.search(
                        f"{token}: synthetic test line"))


class BlockerCountTest(unittest.TestCase):
    """Section 5 carries exactly the declared blocker count."""

    def test_section_five_bullet_count(self):
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        start = audit_text.index("## 5.")
        end = audit_text.index("## 6.")
        section_five = audit_text[start:end]
        bullets = [
            line for line in section_five.splitlines()
            if line.startswith("- ")
        ]
        self.assertEqual(len(bullets), EXPECTED_BLOCKER_COUNT)


class SurfaceKeyTest(unittest.TestCase):
    """A new class must not reuse a surface an existing class owns."""

    def test_surface_keys_are_unique(self):
        surfaces = list(SURFACE_KEYS.values())
        self.assertEqual(len(surfaces), len(set(surfaces)))

    def test_surface_key_count(self):
        self.assertEqual(len(SURFACE_KEYS), 23)


class BulletOverlapTest(unittest.TestCase):
    """Bullets from different classes must not share most characters.

    Boundary notes reference other classes by number. Shared phrasing there
    is by design, so "Boundary:" bullets are exempt.
    """

    def test_no_bullet_pair_overlaps(self):
        audit_text = AUDIT_PATH.read_text(encoding="utf-8")
        start = audit_text.index("## 2.")
        end = audit_text.index("## 3.")
        section_two = audit_text[start:end]
        bullets = [
            line[2:].strip().lower()
            for line in section_two.splitlines()
            if line.startswith("- ") and "boundary:" not in line.lower()
        ]
        violations = []
        for index, first in enumerate(bullets):
            for second in bullets[index + 1:]:
                ratio = difflib.SequenceMatcher(None, first, second).ratio()
                if ratio > OVERLAP_THRESHOLD:
                    violations.append((first, second, ratio))
        self.assertEqual(violations, [])


if __name__ == "__main__":
    unittest.main()
