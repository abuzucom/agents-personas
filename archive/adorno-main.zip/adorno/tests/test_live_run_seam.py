#!/usr/bin/env python3
"""Live-run seam test.

eval/run_eval.py takes a --model-call target but this repository ships no
credential. eval/example_echo.py is the local stand-in. It returns a fixed
synthetic response so the call seam stays tested without a provider.
"""
import importlib.util
import json
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
EXAMPLE_PATH = REPO_ROOT / "eval" / "example_echo.py"
RUN_EVAL_PATH = REPO_ROOT / "eval" / "run_eval.py"


def _load_module(name: str, path: Path):
    """Import a module by path."""
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


echo = _load_module("example_echo", EXAMPLE_PATH)
run_eval = _load_module("run_eval", RUN_EVAL_PATH)


class ExampleEchoTest(unittest.TestCase):
    """The example callable satisfies the --model-call contract."""

    def test_call_model_exists_and_is_callable(self):
        self.assertTrue(hasattr(echo, "call_model"))
        self.assertTrue(callable(echo.call_model))

    def test_call_model_returns_str(self):
        response = echo.call_model("system prompt", "PR", "case text")
        self.assertIsInstance(response, str)


class EchoResponseShapeTest(unittest.TestCase):
    """The fixed response satisfies the harness verdict patterns."""

    def setUp(self):
        self.response = echo.call_model("system prompt", "PR", "case text")

    def test_response_has_matching_verdict_line(self):
        lines = [line for line in self.response.splitlines() if "VERDICT:" in line]
        self.assertTrue(lines)
        match = run_eval.VERDICT_LINE_RE.search(lines[0])
        self.assertIsNotNone(match)

    def test_response_has_parseable_verdict_json(self):
        ok, detail = run_eval.json_companion_ok(self.response)
        self.assertTrue(ok, detail)


if __name__ == "__main__":
    unittest.main()
