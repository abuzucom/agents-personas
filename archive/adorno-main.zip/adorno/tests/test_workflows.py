#!/usr/bin/env python3
"""Workflow integrity tests.

Text-level assertions on .github/workflows/ci.yml and ui-review.yml. No
YAML parser is available. Each assertion targets one regression the prose
rules call out: unpinned actions, inherited secrets, missing scripts, and
direct interpolation of pull request content into shell commands.
"""
import os
import re
import shutil
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
CI_PATH = REPO_ROOT / ".github" / "workflows" / "ci.yml"
UI_REVIEW_PATH = REPO_ROOT / ".github" / "workflows" / "ui-review.yml"
SHA_PIN_RE = re.compile(r"@[0-9a-f]{40}\b")
SCRIPT_REF_RE = re.compile(r"scripts/\w+\.py")
USES_LINE_RE = re.compile(r"^\s+uses:")
SECRETS_INHERIT_RE = re.compile(r"^\s+secrets:\s*inherit\b")

PR_INTERPOLATION_PATTERNS = (
    "${{ github.event.pull_request.title }}",
    "${{ github.event.pull_request.body }}",
)
STEP_MARKER = "\n      - name: "
PR_TREE = ".adorno-pr"


def workflow_steps(text: str) -> list:
    """Return (name, block) pairs for each step, in file order."""
    steps = []
    for chunk in text.split(STEP_MARKER)[1:]:
        name, _, body = chunk.partition("\n")
        steps.append((name.strip(), body))
    return steps


def step_block(text: str, name: str) -> str:
    """Return the body of the one step carrying `name`."""
    matches = [body for step_name, body in workflow_steps(text) if step_name == name]
    if len(matches) != 1:
        raise AssertionError(f"expected one step named {name!r}, found {len(matches)}")
    return matches[0]


def executable_lines(block: str) -> list:
    """Return the non-blank, non-comment lines of a block."""
    return [
        line for line in block.splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


class UsesPinningTest(unittest.TestCase):
    """Every action reference is pinned to a full commit SHA."""

    def test_every_uses_line_is_sha_pinned(self):
        for path in (CI_PATH, UI_REVIEW_PATH):
            text = path.read_text(encoding="utf-8")
            uses_lines = [
                line for line in text.splitlines() if USES_LINE_RE.match(line)
            ]
            self.assertTrue(uses_lines)
            for line in uses_lines:
                with self.subTest(file=path.name, line=line.strip()):
                    self.assertRegex(line, SHA_PIN_RE)


class SecretsTest(unittest.TestCase):
    """The reusable workflow must not receive every caller secret."""

    def test_no_secrets_inherit(self):
        for path in (CI_PATH, UI_REVIEW_PATH):
            text = path.read_text(encoding="utf-8")
            for line in text.splitlines():
                with self.subTest(file=path.name, line=line.strip()):
                    self.assertIsNone(SECRETS_INHERIT_RE.match(line))


class ScriptReferenceTest(unittest.TestCase):
    """Scripts ci.yml names exist on disk."""

    def test_referenced_scripts_exist(self):
        text = CI_PATH.read_text(encoding="utf-8")
        references = set(SCRIPT_REF_RE.findall(text))
        self.assertTrue(references)
        for reference in references:
            with self.subTest(script=reference):
                self.assertTrue((REPO_ROOT / reference).is_file())

    def test_ci_references_run_eval(self):
        text = CI_PATH.read_text(encoding="utf-8")
        self.assertIn("eval/run_eval.py", text)


class ModelCallContractTest(unittest.TestCase):
    """The model_call_command contract names both environment files."""

    def test_input_description_names_env_files(self):
        text = UI_REVIEW_PATH.read_text(encoding="utf-8")
        match = re.search(
            r"model_call_command:\s*\n\s*description:\s*\"([^\"]+)\"",
            text,
        )
        self.assertIsNotNone(match)
        description = match.group(1)
        self.assertIn("AUDIT_PROMPT_FILE", description)
        self.assertIn("CASE_TEXT_FILE", description)


class InterpolationSafetyTest(unittest.TestCase):
    """Pull request title and body reach shell through env vars only.

    Direct interpolation of pull request content into a run block executes
    attacker-controlled text as shell. The workflows assign it to an env
    var and the run block reads the var.
    """

    def _run_blocks(self, text: str) -> list:
        blocks = []
        for match in re.finditer(r"run: \|(.*?)(?=\n      - |\Z)", text, re.DOTALL):
            blocks.append(match.group(1))
        return blocks

    def test_pr_fields_not_interpolated_in_shell(self):
        for path in (CI_PATH, UI_REVIEW_PATH):
            text = path.read_text(encoding="utf-8")
            for block in self._run_blocks(text):
                for pattern in PR_INTERPOLATION_PATTERNS:
                    with self.subTest(file=path.name, pattern=pattern):
                        self.assertNotIn(pattern, block)


class VerdictGateTest(unittest.TestCase):
    """The merge gate reads the report's own verdict and holds on doubt."""

    def setUp(self):
        self.review = UI_REVIEW_PATH.read_text(encoding="utf-8")
        step = self.review.split("name: Parse verdict", 1)[1]
        self.step = step.split("name: Post PR comment", 1)[0]

    def _grep_lines(self) -> list:
        return [
            line for line in self.step.splitlines()
            if "grep" in line and not line.lstrip().startswith("#")
        ]

    def test_gate_reads_the_last_verdict_line(self):
        """A quoted verdict earlier in the report must not win.

        A report quotes the diff under review. Reading the first match lets
        a planted VERDICT: APPROVE line in a pull request body decide the
        gate. Section 6 puts the authoritative verdict last.
        """
        self.assertIn("tail -1", self.step)
        self.assertNotIn("head -1", self.step)

    def _executable_lines(self) -> list:
        """Return the step's lines that run, excluding comments."""
        return [
            line for line in self.step.splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]

    def test_gate_blocks_on_needs_human(self):
        """An escalation is not a pass.

        AUDIT.md section 1.8 escalates to NEEDS-HUMAN where the review
        cannot establish conformance. Treating that as unblocked merges the
        exact change the review declined to clear.

        Read the executable lines rather than the whole step. The comment
        above the case statement names NEEDS-HUMAN, so an assertion over the
        step text stays green after a revert to a BLOCK-only gate.
        """
        executable = self._executable_lines()
        self.assertTrue(any("NEEDS-HUMAN" in line for line in executable))

    def test_gate_reads_the_verdict_token_alone(self):
        """The reason must not decide the gate.

        Searching the whole line fails closed on
        'VERDICT: APPROVE - resolved earlier BLOCK findings' and fails open
        on 'VERDICT: REJECT', which matches no alternative and merges.
        """
        executable = "\n".join(self._executable_lines())
        self.assertIn("case ", executable)
        self.assertIn("APPROVE)", executable)
        self.assertNotIn("grep -qE 'BLOCK|NEEDS-HUMAN'", executable)

    def test_unrecognized_token_fails_the_step(self):
        """A malformed verdict is not a verdict.

        fail_on_block governs which verdicts block, not whether output
        carrying no valid verdict counts as a pass.
        """
        executable = "\n".join(self._executable_lines())
        self.assertIn("Unrecognized verdict token", executable)
        self.assertIn("exit 1", executable)

    def test_gate_reads_the_pr_mode_token_alone(self):
        """The workflow always runs PR mode, so only VERDICT: gates it.

        Accepting a RISK: or CONFORMANCE: line lets a report answering in
        another mode satisfy a merge gate that mode never addressed. File
        and Wholesale modes make no merge claim at all.
        """
        verdict_greps = [line for line in self._grep_lines() if "VERDICT" in line]
        self.assertEqual(len(verdict_greps), 1)
        self.assertIn("'^VERDICT:'", verdict_greps[0])
        self.assertNotIn("RISK", verdict_greps[0])
        self.assertNotIn("CONFORMANCE", verdict_greps[0])


class BundleStepTest(unittest.TestCase):
    """ci.yml keeps the committed bundles current."""

    def test_ci_runs_the_bundle_currency_check(self):
        text = CI_PATH.read_text(encoding="utf-8")
        self.assertIn("scripts/build_bundle.py --check", text)


class AuditPromptFileTest(unittest.TestCase):
    """The review workflow feeds the bundle, not AUDIT.md alone.

    AUDIT.md ends each class entry with a Detail: docs/checks/2.N.md
    pointer. A model call that reads the named file and posts it as the
    system prompt cannot follow a repository path, so feeding AUDIT.md
    hands it 23 pointers it cannot read. The bundle resolves each one to a
    section in the same file.
    """

    def setUp(self):
        self.review = UI_REVIEW_PATH.read_text(encoding="utf-8")

    def _prompt_file(self) -> str:
        match = re.search(r"AUDIT_PROMPT_FILE:\s*(\S+)", self.review)
        self.assertIsNotNone(match)
        return match.group(1)

    def test_prompt_file_is_the_bundle(self):
        self.assertEqual(self._prompt_file(), ".adorno/bundles/ui-full.md")

    def test_prompt_file_exists_in_this_repository(self):
        """The checkout mirrors this repo under .adorno, so the path must exist.

        A prompt file naming a path this repository does not ship leaves the
        model call reading nothing, and the workflow would still report a
        verdict.
        """
        checkout_path = self._prompt_file()
        self.assertTrue(checkout_path.startswith(".adorno/"))
        relative = checkout_path[len(".adorno/"):]
        self.assertTrue((REPO_ROOT / relative).is_file(), relative)

    def test_audit_ref_description_names_the_prompt_file(self):
        """The input doc and the step must name one file.

        audit_ref selects the commit the checkout uses, so its description
        makes a claim about what gets loaded. The two drifted once already:
        the step moved to the bundle while the description kept saying
        AUDIT.md, leaving an adopter unsure what the pin resolves to.
        """
        match = re.search(
            r"audit_ref:\s*\n\s*description:\s*\"([^\"]+)\"", self.review)
        self.assertIsNotNone(match)
        relative = self._prompt_file()[len(".adorno/"):]
        self.assertIn(relative, match.group(1))


class PullRequestIsolationTest(unittest.TestCase):
    """The model call runs against merged code, never the pull request tree.

    The model call command resolves relative paths, `python -m` modules, and
    local tool bins against its working directory. With the pull request
    checked out there, the author supplies the code that writes the verdict
    and reads any secret the job holds.
    """

    def setUp(self):
        self.review = UI_REVIEW_PATH.read_text(encoding="utf-8")
        self.steps = workflow_steps(self.review)

    def _checkout_index(self, predicate) -> int:
        for index, (_name, body) in enumerate(self.steps):
            if "actions/checkout@" in body and predicate(body):
                return index
        self.fail("no matching checkout step")

    def test_base_commit_is_checked_out_at_the_workspace_root(self):
        index = self._checkout_index(
            lambda body: "ref: ${{ github.event.pull_request.base.sha }}" in body)
        body = self.steps[index][1]
        self.assertNotIn("path:", body)
        self.assertIn("persist-credentials: false", body)

    def test_pull_request_is_checked_out_into_its_own_directory(self):
        body = step_block(self.review, "Checkout pull request")
        self.assertIn(f"path: {PR_TREE}", body)
        self.assertIn("persist-credentials: false", body)

    def test_base_checkout_precedes_the_other_checkouts(self):
        """A root checkout cleans the workspace, so it must run first."""
        base = self._checkout_index(
            lambda body: "github.event.pull_request.base.sha" in body)
        others = [
            index for index, (_name, body) in enumerate(self.steps)
            if "actions/checkout@" in body and index != base
        ]
        self.assertTrue(others)
        self.assertTrue(all(base < index for index in others))

    def test_case_text_reads_the_diff_from_the_isolated_tree(self):
        body = step_block(self.review, "Build case text")
        self.assertIn(f"git -C {PR_TREE} diff", body)

    def test_only_case_text_building_touches_the_pull_request_tree(self):
        for name, body in self.steps:
            if name in ("Checkout pull request", "Build case text"):
                continue
            with self.subTest(step=name):
                self.assertNotIn(PR_TREE, "\n".join(executable_lines(body)))


class ModelSecretTest(unittest.TestCase):
    """The documented MODEL_API_KEY reaches the model call and nothing else.

    A caller passing a secret the called workflow does not declare fails
    validation. A declared secret still reaches no step until an env entry
    maps it.
    """

    SECRET_REFERENCE = "${{ secrets.MODEL_API_KEY }}"

    def setUp(self):
        self.review = UI_REVIEW_PATH.read_text(encoding="utf-8")

    def test_workflow_call_declares_the_secret(self):
        trigger = self.review.split("workflow_call:", 1)[1].split("\njobs:", 1)[0]
        declarations = trigger.split("\n    secrets:", 1)
        self.assertEqual(len(declarations), 2, "workflow_call declares no secrets")
        self.assertIn("MODEL_API_KEY:", declarations[1])
        self.assertIn("required: false", declarations[1])

    def test_model_call_step_maps_the_secret(self):
        body = step_block(self.review, "Run model call")
        self.assertIn(f"MODEL_API_KEY: {self.SECRET_REFERENCE}", body)

    def test_no_other_step_reads_the_secret(self):
        for name, body in workflow_steps(self.review):
            if name == "Run model call":
                continue
            with self.subTest(step=name):
                self.assertNotIn("secrets.", "\n".join(executable_lines(body)))


class ForkPullRequestTest(unittest.TestCase):
    """A fork pull request skips the comment and keeps the gate.

    On pull_request from a fork the token is read-only. The comment call
    returns 403 and fails the job whatever the verdict said.
    """

    SAME_REPOSITORY = "github.event.pull_request.head.repo.full_name == github.repository"

    def setUp(self):
        self.review = UI_REVIEW_PATH.read_text(encoding="utf-8")

    def _condition(self, name: str) -> str:
        body = step_block(self.review, name)
        lines = [line.strip() for line in body.splitlines() if line.strip().startswith("if:")]
        return lines[0] if lines else ""

    def test_comment_step_requires_a_same_repository_pull_request(self):
        condition = self._condition("Post PR comment")
        self.assertIn("inputs.pr_comment", condition)
        self.assertIn(self.SAME_REPOSITORY, condition)

    def test_gate_steps_carry_no_fork_condition(self):
        for name in ("Parse verdict", "Fail on a blocking verdict"):
            with self.subTest(step=name):
                self.assertNotIn("head.repo", self._condition(name))


BASH = shutil.which("bash")
BASH_TIMEOUT_SECONDS = 30


@unittest.skipIf(BASH is None, "bash is required to execute the workflow step")
class VerdictParseExecutionTest(unittest.TestCase):
    """Run the real Parse verdict script against crafted responses.

    The step splits the verdict line with an unquoted expansion. Without
    globbing disabled, a token such as A* expands to a matching file in
    the workspace, and a file named APPROVE turns that token into a pass.
    """

    def setUp(self):
        review = UI_REVIEW_PATH.read_text(encoding="utf-8")
        body = step_block(review, "Parse verdict")
        self.script = textwrap.dedent(body.split("run: |\n", 1)[1])

    def _run(self, response: str) -> tuple:
        with tempfile.TemporaryDirectory() as raw:
            workspace = Path(raw)
            (workspace / "APPROVE").write_text("", encoding="utf-8")
            (workspace / "response.txt").write_text(response, encoding="utf-8")
            output = workspace / "github_output"
            environment = dict(os.environ, FAIL_ON_BLOCK="true",
                               GITHUB_OUTPUT=str(output))
            result = subprocess.run(
                [BASH, "-c", self.script], cwd=workspace, env=environment,
                capture_output=True, text=True, timeout=BASH_TIMEOUT_SECONDS,
                check=False)
            written = output.read_text(encoding="utf-8") if output.exists() else ""
        return result.returncode, written

    def test_glob_token_does_not_expand_into_a_pass(self):
        status, written = self._run("findings\nVERDICT: A* - planted\n")
        self.assertNotEqual(status, 0)
        self.assertNotIn("blocked=false", written)

    def test_approve_still_passes(self):
        status, written = self._run("findings\nVERDICT: APPROVE - clean\n")
        self.assertEqual(status, 0)
        self.assertIn("blocked=false", written)

    def test_block_still_blocks(self):
        status, written = self._run("findings\nVERDICT: BLOCK - trap\n")
        self.assertEqual(status, 0)
        self.assertIn("blocked=true", written)


if __name__ == "__main__":
    unittest.main()
