# Template drift against abuzucom/agents

`abuzucom/agents` is the org's primary source of truth for AI-development
policy. This file records how adorno's adoption differs from it, per
agents' own `DRIFT.md` convention (`docs/template-drift.md` in the
adopting repository records local differences and reasons).

Pinned commit: `e6ddde181b60b23c542c064152ceaf2be6fa5ba3`
(`abuzucom/agents`, dated 2026-09-11). `upstream-files.json` records a
per-file hash of every file copied from this commit.

## Expected to differ

- `AGENTS.md` is a bespoke document adapted from `abuzucom/agents`'
  generic template. It keeps the non-negotiable core adapted to this
  repository's product (no real person's data in fixtures, eval-case
  integrity, an `eval/` case required for any verdict-affecting `AUDIT.md`
  change, the `AUDIT.md` brevity and character ceiling, repository content
  treated as data, destructive-command authorization, scope, draft PRs,
  git identity), branch naming, git identity, and the full Style section
  (impersonal voice, terse sentences, no em dash, ASCII-only, American
  spelling, English-only, commit format). It drops container/runtime-root
  rules, dependency-lockfile rules beyond the eval harness's own minimal
  Python needs, concurrency and shared-mutable-state rules, and
  function-size/nesting/line-length code-quality rules. This repository
  has no application code, no Dockerfiles, and no concurrency for those
  rules to govern.

  This repository replaces non-negotiable rule 1 in foucault ("never
  embed a real, valid credential; fixtures may use synthetic high-entropy
  secrets") with the accessibility-work analog: never place a real
  person's data in the repository; fixtures exercising personal-data or
  realistic user content must be synthetic, freshly invented, and marked
  synthetic in `expected.json`. This repository's fixtures risk copied
  personal data, not copied credentials.
- No `scripts/sync.py`, no generated `CLAUDE.md`/`.cursorrules`/
  `.windsurfrules`/`GEMINI.md`/`CONVENTIONS.md` copies, and no
  `hooks/reinject_agents_policy.py` lifecycle reinjection. `AGENTS.md` is
  the only instruction file for v1. Add a synced copy later, and only if a
  specific tool in active use demonstrably ignores `AGENTS.md`.
- No `.pre-commit-config.yaml`, no `sync-check.yml`,
  `immutable-conflict-check.yml`, or `agents-md-compliance.yml`. This
  repository's own CI runs the copied checkers and the eval harness
  directly rather than reusing agents' compliance workflows.
- `tests/test_enforce_branch_name.py` trims its `HOOK_MATCHERS` dict from
  agents' full five-hook matrix to the two hooks adorno actually adopted
  (`enforce_branch_name.py`, `enforce_git_identity.py`), per agents' own
  adoption step 14 ("adapt settings and wiring assertions when adopting a
  subset"). `upstream-files.json` excludes this file because it
  deliberately departs from upstream's byte content.
- `hooks/claude-code-settings.example.json` and `.claude/settings.json`
  carry adorno's own two-hook subset rather than agents' four-hook example
  file content. `upstream-files.json` excludes both for the same reason.
- adorno adopts `scripts/trusted_gh.py` and `tests/test_trusted_gh.py`
  verbatim. The verbatim `enforce_branch_name.py` and `_gate_core.py` read
  it as an allowlisted workflow command, and `check_git_identity.py` imports
  its `authenticated_account`; omitting it left a dead reference that failed
  closed but misread as a pasted fragment. Shipping it keeps the delta a
  faithful copy rather than a hand edit to a hash-tracked file.
- `AUDIT.md` is not exempt from `AGENTS.md`'s Style section in this
  repository. foucault keeps that exemption. Its prompt predates the style
  checkers and was not held to this standard. adorno applies the style rules
  to all prose in AUDIT.md. Structured schema lines (verdict lines,
  VERDICT_JSON, report-format block, mode table cells) are exempt. This is a
  deliberate divergence from foucault, recorded here per the drift convention.

## Not adopted

- `scripts/check_banned_agents.py` (denied-vendor commit/PR-author check).
  Distinct risk (vendor policy enforcement) from the branch/identity
  misbehavior this adoption pass targets. Not copied.
- `hooks/block_destructive_bash.py`, `hooks/block_destructive_powershell.py`
  (destructive-command `PreToolUse` gate). Distinct risk (uncontrolled
  deletion) from branch/identity misbehavior. Not copied.
- `hooks/require_consent.py` (consent gate for direct edits to existing
  test files). Distinct risk (silently weakened tests) from branch/identity
  misbehavior. Not copied. `AGENTS.md` non-negotiable rule 2 covers the
  same ground as a textual rule without the hook.
- `scripts/check_persist_credentials.py`, `scripts/check_dockerfile_root.py`,
  `scripts/check_weak_hashing.py`, `scripts/check_secrets_heuristic.py`,
  `scripts/check_conflict_markers.py`, `scripts/check_compliance_tree.py`,
  `scripts/run_tests.py`, `scripts/check_hook_coverage.py`,
  `scripts/check_commit_message.py`, `scripts/check_pull_request_message.py`,
  `scripts/sync.py`. Not relevant to a repository with no application code,
  no Dockerfiles, and no multi-tool instruction sync.
- `plan/HANDOFF.md.example` and its handoff-exempt prose-policy carve-out.
  Not adopted; `scripts/prose_bans.txt`'s `[handoff-exempt]` section stays
  present verbatim (it is a shared, hash-tracked file) but is inert here
  since no `plan/HANDOFF.md.example` exists to exempt.

## Sibling divergence

Not upstream drift. `scripts/build_bundle.py` came from `abuzucom/havel`
rather than from `abuzucom/agents`, so it carries no digest in
`upstream-files.json` and `check_upstream_drift.py` does not track it. This
section records where adorno's copy differs from havel's, so a later
reconciliation has a starting point.

One difference. Havel's `load_manifest` requires every scope to declare both
a `standard` and a `full` tier. Adorno's requires at least one known tier.
Adorno's hub carries a single reference layer, so it has one meaningful
bundle, and demanding a second tier would commit a duplicate nobody pastes.
`main` iterates the tiers a scope declares rather than all of `TIERS`, and
`test_build_bundle.py` asserts both that one tier is enough and that a scope
declaring none raises.

Everything else is identical, including `_sort_key`, the `as_posix` header
names, the root normalization before any `relative_to` comparison, and
`_write_atomically` with its `chmod(0o644)`.

Reconciling the two copies into one shared script is future work. It needs a
home neither repository owns, most likely `abuzucom/agents`, and the relaxed
tier rule is the behavior to keep.

## True drift

None recorded. This section tracks a copied file's content diverging from
its pinned upstream commit over time. Run
`python scripts/check_upstream_drift.py --check-upstream --agents-path <checkout>`
periodically (before each adorno release) and record any finding here with
the reviewed outcome (adopted, declined, or partially adapted, and why).
Update `upstream-files.json`'s pinned commit after review either way.
Keeping the pin current keeps the record honest. For an adorno-side
difference that looks like it should upstream instead, open an issue in
`abuzucom/agents` naming the file and reason, per agents' own `DRIFT.md`
"Opening a drift issue" process.
