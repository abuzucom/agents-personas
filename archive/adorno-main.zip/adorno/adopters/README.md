# Adopters

Records of repositories that load `AUDIT.md` as a UI/UX and accessibility
audit agent's system prompt, or wire the reference
`.github/workflows/ui-review.yml`. Mirrors the `adopters/<repo>.md`
convention from `abuzucom/agents`.

## Recording an adoption

Add `adopters/<repo>.md` with:

- The pinned tag or commit SHA of `AUDIT.md` in use.
- Any customization made per the README's Customization section
  (framework-specific additions, scope boundaries, a waiver mechanism).
- Whether the repository wires `.github/workflows/ui-review.yml`, and at
  what pinned commit SHA.

## Current adopters

None recorded yet.
