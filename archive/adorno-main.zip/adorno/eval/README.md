# Eval harness

Golden-corpus regression tests for `AUDIT.md`. Each case under `cases/` is a
small UI/UX or accessibility sample (a diff, a component, a fragment, a
design source plus its implementation) paired with the verdict a careful
reviewer applying `AUDIT.md` should produce. `AGENTS.md` requires a new or
updated case for any change to `AUDIT.md` that affects a verdict, a hard
blocker, or a severity mapping.

## Why this exists

`AUDIT.md` is a system prompt. Nothing about a well-written instruction
document guarantees a model actually follows it. This harness is the
difference between trusting the prompt and checking it: run every case
against a real model call and confirm the verdicts still match after any
edit.

## Model-agnostic by design

`run_eval.py` never calls a model API and ships no credentials. Point it at
a locally supplied callable:

```console
python eval/run_eval.py --model-call mymodule:call_model
```

`call_model(system_prompt, mode, case_text) -> str` receives
`bundles/ui-full.md` as `system_prompt`. That bundle is the prompt
deployments paste. `AUDIT.md` alone carries `Detail:` pointers a model
cannot follow. The callable sends `system_prompt` as the system prompt,
sends `case_text` (the fixture plus any `context.md`) as a user-turn
message, and returns the model's raw text response. Wire it to
whichever provider and model an `AUDIT.md` deployment actually uses. This
repository does not prescribe one.

`--model-call` resolves to an importable module and executes its code. Treat
it as a trusted input. Supply it only from a local invocation or a CI
configuration under this repository's control, never from pull request
content or any other value an outside contributor can influence. `ci.yml`
never passes it.

Without `--model-call`, the script runs structure-only. It confirms every
`expected.json` and fixture file parses and is internally consistent, then
exits 0. This is what runs in this repository's own CI, since adorno ships
no model credential. Any consumer with a model credential can run the live
check the same way.

## Case format

```
eval/cases/<slug>/
  diff.patch | input.<ext> | spec.md + tokens.json + input.<ext>
  context.md                 optional: PR description, ticket text, or design context
  expected.json              required
```

A Design-spec-mode case pairs a design source (`spec.md`, `tokens.json`, or
similar) with the implementation under review (`input.<ext>` or
`diff.patch`).

`expected.json` fields:

| Field | Meaning |
|---|---|
| `mode` | `PR`, `File`, `Piece`, `Wholesale`, or `Design-spec` (AUDIT.md section 0) |
| `expected_verdict` | Substring the response's `VERDICT:`/`RISK:`/`CONFORMANCE:` line must contain, e.g. `BLOCK`, `RISK: CRITICAL`, `CONFORMANCE: MISMATCH`, `RISK (partial)` |
| `expected_classes` | AUDIT.md section 2.x references the case exercises |
| `expect_json` | If `true`, the harness also requires a parseable `VERDICT_JSON:` block (AUDIT.md section 6) |
| `notes` | Why this verdict is correct, for a human reviewing the case |
| `fixture_notes` | Optional: provenance of any user-content-shaped or personal-data-shaped value in the fixture (see below) |

## User-content-shaped fixtures

A case exercising personal data, names, addresses, or realistic user content
needs values that read as real, because realism is the signal certain checks
key on. `AGENTS.md` non-negotiable rule 1 requires this for every case:
synthetic and freshly invented for every value that must read as genuine,
obviously placeholder-shaped (Example, 555-01xx ranges, `user@example.com`)
where the case must not imply a real person, never copied from a real user,
a real person, or any production data source. `expected.json` must mark such
a fixture synthetic.

## Current cases

| Case | Mode | Tests |
|---|---|---|
| `keyboard-inaccessible-modal-pr` | PR | 2.1/2.2, a `div` modal button with no keyboard path, hard blocker |
| `clean-labeled-form-file` | File | section 8, a correctly labeled, keyboard-operable form is not a finding; section 9 zero-findings |
| `heading-structure-file` | File | 2.1, headings as styled divs and out-of-order levels |
| `focus-not-visible-file` | File | 2.2, focus outline removed with no replacement |
| `unlabeled-icon-button-file` | File | 2.3, an icon-only button with no accessible name |
| `color-only-status-file` | File | 2.4, validation shown by color alone |
| `error-not-announced-file` | File | 2.5, a submission error with no text or field association |
| `autoplay-video-no-reduced-motion-file` | File | 2.6, auto-playing motion with no pause or reduced-motion path |
| `async-result-not-announced-file` | File | 2.7, async results injected with no live region or focus management |
| `video-no-captions-file` | File | 2.8, informational video with no captions or transcript |
| `small-touch-target-file` | File | 2.9, targets under 24x24 CSS pixels |
| `no-reflow-tsx-file` | File | 2.10, a fixed-width layout that does not reflow |
| `missing-lang-file` | File | 2.11, a document with no `lang` attribute |
| `confirmshaming-dark-pattern-file` | File | 2.12, a shaming decline option on an opt-in |
| `hover-only-tooltip-file` | File | 2.13, critical info available only on hover |
| `design-spec-token-mismatch` | Design-spec | 2.14, implementation diverging from the design source |
