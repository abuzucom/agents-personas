#!/usr/bin/env python3
"""Golden-corpus harness for AUDIT.md.

Validates every case under eval/cases/ against its expected.json. Model
invocation is pluggable: this script never calls a model API directly and
ships no credentials. Point --model-call at a Python callable to run cases
live; omit it to run structure-only (the default), which validates fixture
and expected.json shape without asking a model anything.

Usage:
    python eval/run_eval.py
    python eval/run_eval.py --model-call mymodule:call_model
    python eval/run_eval.py --case keyboard-inaccessible-modal-pr --model-call mymodule:call_model

A --model-call target is a callable with the signature:
    call_model(system_prompt: str, mode: str, case_text: str) -> str
returning the model's raw text response (the human-readable report,
including its final VERDICT:/RISK:/CONFORMANCE: line and, where AUDIT.md
section 6 requires it, the VERDICT_JSON companion block).
"""

from __future__ import annotations

import argparse
import importlib
import json
import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
AUDIT_PATH = REPO_ROOT / "AUDIT.md"
# A live run sends the bundle deployments paste. AUDIT.md alone carries 23
# Detail: pointers a model cannot follow, so grading it scores a prompt no
# deployment uses and never exercises a docs/checks/ edit.
BUNDLE_PATH = REPO_ROOT / "bundles" / "ui-full.md"
CASES_DIR = Path(__file__).resolve().parent / "cases"

VALID_MODES = {"PR", "File", "Piece", "Wholesale", "Design-spec"}
CASE_INPUT_NAMES = (
    "diff.patch",
    "input.jsx",
    "input.tsx",
    "input.tsx.txt",
    "input.js",
    "input.ts",
    "input.py",
    "input.html",
    "input.css",
    "input.md",
    "input.txt",
    "spec.md",
    "tokens.json",
)

VERDICT_LINE_RE = re.compile(
    r"^(VERDICT|RISK(?: \(partial\))?|CONFORMANCE):\s*(.+)$", re.MULTILINE
)
VERDICT_JSON_PREFIX = "VERDICT_JSON:"

# Section 6 gives each mode one verdict token. Grading a response against the
# wrong one lets a report answering in another mode satisfy a check that mode
# never addressed. File and Wholesale make no merge claim at all.
MODE_VERDICT_TOKENS = {
    "PR": "VERDICT",
    "File": "RISK",
    "Wholesale": "RISK",
    "Piece": "RISK (partial)",
    "Design-spec": "CONFORMANCE",
}


class CaseError(Exception):
    pass


def load_case(case_dir: Path) -> dict:
    expected_path = case_dir / "expected.json"
    if not expected_path.is_file():
        raise CaseError(f"{case_dir.name}: missing expected.json")
    expected = json.loads(expected_path.read_text(encoding="utf-8"))

    for key in ("mode", "expected_verdict", "expected_classes", "notes"):
        if key not in expected:
            raise CaseError(f"{case_dir.name}: expected.json missing '{key}'")
    if expected["mode"] not in VALID_MODES:
        raise CaseError(
            f"{case_dir.name}: mode '{expected['mode']}' not one of {sorted(VALID_MODES)}"
        )
    # allow_non_ascii is a structural flag for corpus tests. It does not
    # change harness behavior. A case with non-ASCII fixture content must
    # set allow_non_ascii: true and state the reason in fixture_notes.
    if expected.get("allow_non_ascii") and "fixture_notes" not in expected:
        raise CaseError(
            f"{case_dir.name}: allow_non_ascii: true requires fixture_notes explaining why"
        )

    input_files = [
        case_dir / name for name in CASE_INPUT_NAMES if (case_dir / name).is_file()
    ]
    if not input_files:
        raise CaseError(f"{case_dir.name}: no recognized input file present")

    context_path = case_dir / "context.md"
    context_text = context_path.read_text(encoding="utf-8") if context_path.is_file() else ""

    case_text = "\n\n".join(p.read_text(encoding="utf-8") for p in input_files)
    return {
        "name": case_dir.name,
        "mode": expected["mode"],
        "expected": expected,
        "context": context_text,
        "case_text": case_text,
    }


def discover_cases(only: str | None = None) -> list[dict]:
    if not CASES_DIR.is_dir():
        raise CaseError(f"cases directory not found: {CASES_DIR}")
    dirs = sorted(p for p in CASES_DIR.iterdir() if p.is_dir())
    if only:
        dirs = [p for p in dirs if p.name == only]
        if not dirs:
            raise CaseError(f"no case named '{only}' under {CASES_DIR}")
    return [load_case(d) for d in dirs]


def verdict_matches(expected_verdict: str, response_text: str, *,
                    mode: str = None) -> tuple[bool, str]:
    """Grade the report's own verdict line against the expected token.

    mode is keyword-only and optional so an existing two-argument call keeps
    working. Where it is given, the response must answer in that mode.
    """
    # A report quotes the diff under review, and a diff is attacker
    # controlled. Section 6 puts the authoritative verdict last, so read the
    # final match rather than a quoted lookalike appearing earlier.
    matches = list(VERDICT_LINE_RE.finditer(response_text))
    if not matches:
        return False, "no VERDICT:/RISK:/CONFORMANCE: line found in response"
    match = matches[-1]
    actual_line = f"{match.group(1)}: {match.group(2)}".strip()
    required = MODE_VERDICT_TOKENS.get(mode) if mode else None
    if required and match.group(1) != required:
        return False, (f"{mode} mode requires a {required}: line, "
                       f"got '{actual_line}'")
    # Compare against the verdict alone. Searching the whole line lets the
    # reason decide the grade, so an expected BLOCK matched
    # 'VERDICT: APPROVE - no BLOCK conditions observed' and scored a failing
    # case as a pass. Section 6 separates the reason with ' - '.
    severity = match.group(2).split(" - ", 1)[0].strip()
    # Fixtures store the verdict in four shapes: a bare severity ('BLOCK'),
    # the prefixed form ('RISK: MEDIUM'), the prefix alone
    # ('RISK (partial)'), and the prefix with its colon ('RISK:'), which
    # asserts the mode answered without pinning a severity.
    accepted = {
        severity,
        f"{match.group(1)}: {severity}",
        match.group(1),
        f"{match.group(1)}:",
    }
    if expected_verdict in accepted:
        return True, actual_line
    return False, actual_line


def json_companion_ok(response_text: str) -> tuple[bool, str]:
    prefix_at = response_text.rfind(VERDICT_JSON_PREFIX)
    if prefix_at < 0:
        return False, "no VERDICT_JSON: block found"
    brace_at = response_text.find("{", prefix_at)
    if brace_at < 0:
        return False, "VERDICT_JSON block carries no object"
    # raw_decode reads one value and ignores whatever follows. A greedy regex
    # instead runs to the last brace in the report, so any later prose
    # carrying a brace breaks the parse.
    try:
        json.JSONDecoder().raw_decode(response_text, brace_at)
    except json.JSONDecodeError as exc:
        return False, f"VERDICT_JSON block did not parse: {exc}"
    return True, "VERDICT_JSON parsed"


def load_system_prompt() -> str:
    """Return the bundle text a live run sends as the system prompt."""
    return BUNDLE_PATH.read_text(encoding="utf-8")


def resolve_model_call(spec: str):
    module_name, _, func_name = spec.partition(":")
    if not module_name or not func_name:
        raise CaseError("--model-call must be in the form module:function")
    sys.path.insert(0, str(REPO_ROOT))
    module = importlib.import_module(module_name)
    return getattr(module, func_name)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", help="run only the named case")
    parser.add_argument(
        "--model-call",
        help="module:function callable invoked as call(system_prompt, mode, case_text) -> str",
    )
    args = parser.parse_args()

    if not BUNDLE_PATH.is_file():
        print(f"bundle not found at {BUNDLE_PATH}. Run scripts/build_bundle.py.",
              file=sys.stderr)
        return 1
    system_prompt = load_system_prompt()

    try:
        cases = discover_cases(args.case)
    except CaseError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if not args.model_call:
        print(f"structure check only: {len(cases)} case(s) validated, no model call configured")
        for case in cases:
            print(f"  ok  {case['name']} (mode={case['mode']})")
        return 0

    model_call = resolve_model_call(args.model_call)

    failures = 0
    for case in cases:
        response = model_call(system_prompt, case["mode"], case["context"] + "\n\n" + case["case_text"])
        ok, detail = verdict_matches(case["expected"]["expected_verdict"], response,
                                     mode=case["mode"])
        status = "pass" if ok else "FAIL"
        print(f"  {status}  {case['name']}: expected '{case['expected']['expected_verdict']}', got '{detail}'")
        if not ok:
            failures += 1

        if case["expected"].get("expect_json"):
            json_ok, json_detail = json_companion_ok(response)
            json_status = "pass" if json_ok else "FAIL"
            print(f"  {json_status}  {case['name']} (VERDICT_JSON): {json_detail}")
            if not json_ok:
                failures += 1

    total = len(cases)
    print(f"\n{total - failures}/{total} verdict checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
