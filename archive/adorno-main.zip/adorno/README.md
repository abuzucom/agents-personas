# Adorno

> **Development moved to `abuzucom/agents-personas`.** This repository
> receives no further changes. The adorno persona lives in
> [`reviewers/adorno/`][moved-persona] there. New callers use
> [`.github/workflows/adorno-ui-review.yml`][moved-wrapper].
> [`docs/migration.md`][moved-migration] maps the inputs of this
> repository's `ui-review.yml`. Existing pins keep working while this
> repository stays available.

[moved-persona]: https://github.com/abuzucom/agents-personas/tree/main/reviewers/adorno
[moved-wrapper]: https://github.com/abuzucom/agents-personas/blob/main/.github/workflows/adorno-ui-review.yml
[moved-migration]: https://github.com/abuzucom/agents-personas/blob/main/docs/migration.md

Operating instructions for an AI agent that audits interfaces for UI/UX and accessibility defects. Targets the barriers common in AI-assisted coding. An interface renders and demos fine while a keyboard user, a screen-reader user, a low-vision user, or a motion-sensitive user cannot complete a task with it.

## What This Is

AUDIT.md is a system prompt and instruction document. Load it into an audit agent (CI bot, PR reviewer, IDE assistant, or batch scan) as its operating instructions. It defines:

- Five review modes. PR (diff, merge-gated). File (one component on demand). Piece (a fragment with unseen context). Wholesale (an entire interface). Design-spec (a design source audited against its implementation). The failure-mode classes apply in every mode. The workflow and verdict adapt to the context available.
- Operating principles. Assume AI-generated output. Think like an excluded user. Prioritize by completeness of exclusion. Know the mode and what is out of view.
- Fifteen failure-mode classes. Non-semantic elements. Keyboard and focus. Naming and labeling. Visual and color. Forms and feedback. Motion. Dynamic content. Media. Target size. Structure and reflow. Readability. Dark patterns. Responsive and input. Design-system drift. AI-generated UI.
- An 8-step workflow. Context. Design source. Structure and semantics. Sensory and input. Dynamic behavior. Media and intent. Consistency. Report. Each step states its per-mode substitution.
- Hard blockers. A short list of catastrophic exclusions that auto-BLOCK with no discretion.
- Mode-appropriate verdicts. APPROVE, BLOCK, NEEDS-HUMAN for PRs. A prioritized RISK summary for File and Wholesale. Findings plus an assumptions block for Piece. A spec-conformance verdict for Design-spec. A VERDICT_JSON companion on every mode. CI gates on structure instead of prose.
- False-positive rules and calibration. What not to flag. The ban on inflating severity.

## Usage

1. Place the audit prompt at the top of the agent context (system prompt), before any code. Paste `bundles/ui-full.md`, not AUDIT.md alone. AUDIT.md ends each class entry with a `Detail: docs/checks/2.N.md` pointer, and a chat window cannot follow a repository path. The bundle is AUDIT.md concatenated with every check file, so each pointer resolves to a section further down the same paste. Pasting AUDIT.md by itself hands the agent 23 pointers it cannot read, and it will fill the gap by inference.
2. Establish the review mode (section 0) from what is fed to the agent: a diff (PR), a file (File), a fragment (Piece), a tree (Wholesale), or a spec plus implementation (Design-spec). When in doubt, the agent defaults to the narrower mode.
3. Have the agent execute the section 3 workflow as explicit, labeled steps. If the platform supports multi-step prompting, run each pass separately with only its relevant sections.
4. Require the final line for the mode as output: the VERDICT line in PR mode (gate merges on it), the RISK summary in File/Wholesale mode, the CONFORMANCE line in Design-spec mode.
5. Validate against historical PRs or files with known issues before enforcing.

### Which file to paste

| File | Size | Use |
|---|---|---|
| `bundles/ui-full.md` | 109646 bytes | The paste. Carries AUDIT.md and all 23 check files. |
| `AUDIT.md` | 22031 bytes | A tool that can read `docs/checks/` from the repository itself. |

`bundles/ui-full.md` is generated. Do not edit it. Edit AUDIT.md or the file under `docs/checks/`, then run:

python scripts/build_bundle.py

`bundles.json` declares what goes into each bundle. CI runs `scripts/build_bundle.py --check` and fails when a committed bundle no longer matches its sources.

## Versioning

Pin a tag or commit SHA when loading AUDIT.md into a deployment rather than tracking main. CHANGELOG.md records what changed release to release, including any change to a verdict, a hard blocker, or the VERDICT_JSON schema. Record the pin in adopters/<repo-name>.md.

## Verifying Changes

eval/ holds a golden corpus. Small fixtures are paired with the verdict AUDIT.md should produce for each. Run the following to validate the case set's structure:

python eval/run_eval.py

Add --model-call module:function to run it against a real model. See eval/README.md. Any change to AUDIT.md affecting a verdict, a hard blocker, or a severity mapping ships with a new or updated case.

## CI Integration

.github/workflows/ui-review.yml is a reusable workflow_call reference implementation. It checks out a pull request diff, loads bundles/ui-full.md, runs an adopter-supplied model-call command, posts the report as a PR comment, and optionally fails the check on BLOCK. It loads the bundle rather than AUDIT.md for the reason in Usage: a model call that posts the named file as its system prompt cannot follow a docs/checks/ path. Adorno ships no model credential and no provider lock-in. The model call is one shell command supplied by the adopting repository, reading $AUDIT_PROMPT_FILE and $CASE_TEXT_FILE and writing the response to stdout. Adorno ships no working example of that command: eval/example_echo.py returns a fixed string for harness testing and must never judge a real case. Pin the uses line and the audit_ref input to the same full commit SHA. See the workflow file header comment for the exact adoption snippet.

The command runs from a checkout of the pull request's base commit. The pull request itself sits under `.adorno-pr` and supplies only the diff. Never point the command at a path inside `.adorno-pr`. Code there comes from the pull request author. Pass the provider credential as the `MODEL_API_KEY` secret. Only the model call step receives it.

Fork pull requests get a read-only token and no secrets on `pull_request`. The workflow skips the PR comment for a fork. A model call that needs `MODEL_API_KEY` fails there, and the job fails closed. Never switch the caller to `pull_request_target` to work around this limit.

## Customization

The document is stack-agnostic by design. Recommended additions for a deployment:

- The frameworks, component library, design-token format, and assistive-technology target set in use. This makes fixes concrete.
- Scope boundaries. Monorepo paths. Vendored and generated files to skip.
- A finding suppression or waiver mechanism and who may use it.

## Structure

| Section | Purpose |
|---|---|
| 0 | Review modes (PR, File, Piece, Wholesale, Design-spec) |
| 1 | Operating principles |
| 2 | Failure-mode classes (2.1-2.16) |
| 3 | Review workflow (mode-aware) |
| 4 | Test quality rules |
| 5 | Hard blockers |
| 6 | Reporting format |
| 7 | Prohibitions, including prompt-injection defense |
| 8 | False positives |
| 9 | Zero-findings protocol |

Each class entry in section 2 is a summary. Its thresholds, mechanism prose, and investigation steps live in `docs/checks/2.N.md`, and `bundles/ui-full.md` carries both.

## Organization Policy Suite

Adorno and abuzucom/agents share a philosophy: defend against AI-assisted coding failure modes. Each covers a different point in time.

- **abuzucom/agents** guards work in progress and future progress. It is proactive and hook-enforced. A canonical AGENTS.md, synced copies for coding-agent tools, and Claude Code hooks that block a violation live, before a commit or a tool call completes.
- **adorno** reviews a pull request or a piece of work on demand. It is reactive and manually or CI invoked. A system prompt for a UI/UX and accessibility audit agent, run against a diff, a file, a fragment, a design source, or a whole tree, after the interface already exists.

Each repository maintains its own document independently. The different trigger model makes drift an expected outcome, not a defect. This repository's own AGENTS.md is a bespoke subset of the abuzucom/agents template, not a copy of it. docs/template-drift.md records the kept and dropped rules, the reason for each, and drift against the pinned upstream commit.

## Contributing

See AGENTS.md for the rules governing changes to this repository. Any change to AUDIT.md affecting a verdict, blocker, or severity mapping ships with an eval/ case demonstrating it.
