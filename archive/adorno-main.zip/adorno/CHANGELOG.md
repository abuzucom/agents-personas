# Changelog

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning follows SemVer. Pin a tag or commit SHA when loading `AUDIT.md`
into a deployment.

## [Unreleased]

### Deprecated

- Announce the move to `abuzucom/agents-personas` at the top of the
  README. The adorno persona continues there under `reviewers/adorno/`.
  This repository receives no further changes.

### Added

- `scripts/build_bundle.py`, `bundles.json`, and `bundles/ui-full.md`: a
  paste-ready concatenation of `AUDIT.md` and every `docs/checks/` file,
  109646 bytes. `AUDIT.md` ends each class entry with a
  `Detail: docs/checks/2.N.md` pointer, and a chat window cannot follow a
  repository path, so pasting `AUDIT.md` alone handed the agent 23 pointers
  it could not read. The builder is manifest-driven and knows nothing about
  classes or checks. `scripts/build_bundle.py --check` regenerates every
  bundle in memory and fails on any byte difference, and CI runs it.
- `AUDIT.md`: the UI/UX and accessibility audit-agent system prompt. Five
  review modes (PR, File, Piece, Wholesale, Design-spec), operating
  principles, fifteen failure-mode classes (2.1-2.15), a mode-aware 8-step
  workflow, a deliberately short catastrophic-only hard-blocker list
  (section 5), a reporting format with a `VERDICT_JSON` machine-readable
  companion, prompt-injection and false-positive discipline, and a
  zero-findings protocol.
- `eval/`: a model-agnostic golden-corpus harness (`run_eval.py`) and
  sixteen fixtures. Three cover a catastrophic hard blocker (PR),
  false-positive and zero-findings discipline (File), and design-source
  conformance (Design-spec). Thirteen more cover failure-mode classes
  2.1-2.13 and 2.15 with one File-mode fixture each.
- `.github/workflows/ui-review.yml`: a reusable, adoptable reference CI
  workflow that runs `AUDIT.md` against a pull request and posts the report.
  `.github/workflows/ci.yml`: runs the structural eval, hook tests, upstream
  drift check, and prose checkers.
- `AGENTS.md`: a bespoke, UI/UX-accessibility-work-specific instruction file
  for this repository (not a copy of `abuzucom/agents`' generic template).
  Adopts the branch-name and git-identity Claude Code hooks in full, plus
  the style/prose checker scripts, from `abuzucom/agents`.
- `docs/template-drift.md`, `upstream-files.json`,
  `scripts/check_upstream_drift.py`: drift tracking against the pinned
  `abuzucom/agents` commit, and a mechanism for reviewing upstream changes
  for adoption.
- `adopters/`: adoption-tracking scaffold.
- `CONTRIBUTING.md` and `SECURITY.md`.

### Fixed

- `.github/workflows/ui-review.yml` ran `model_call_command` inside the pull
  request checkout. The documented `python ci/call_model.py` then executed
  code the pull request author wrote. That code could print
  `VERDICT: APPROVE` and read any secret the job held. The workflow now
  checks out the base commit at the workspace root and the pull request
  under `.adorno-pr`. The diff comes from `.adorno-pr` alone.
- `.github/workflows/ui-review.yml` declared no secrets. The adoption
  snippet passed `MODEL_API_KEY`, which GitHub rejects for an undeclared
  secret. No step mapped it either. The workflow now declares an optional
  `MODEL_API_KEY` and exposes it to the model call step alone.
- The verdict gate split the verdict line with globbing on. A token such as
  `A*` expanded to a workspace file named `APPROVE` and passed. The step now
  sets `set -f` first. A test runs the step under bash.
- A fork pull request runs with a read-only token. The PR comment returned
  403 and failed the job whatever the verdict said. The comment now runs
  for same-repository pull requests only. The verdict steps stay
  unconditional.
- `eval/run_eval.py` sent `AUDIT.md` as the system prompt on a live run.
  Deployments paste `bundles/ui-full.md`. Eval scored a prompt no
  deployment uses and never exercised a `docs/checks/` edit. It now sends
  the bundle.
- `.github/workflows/ui-review.yml` fed `AUDIT.md` to the model call as
  `$AUDIT_PROMPT_FILE`. A model call that reads the named file and posts it
  as the system prompt cannot follow a `docs/checks/` path, so the workflow
  reproduced in CI the exact defect the bundle was added to fix: 23 pointers
  the model could not read. It now names `bundles/ui-full.md`. A test
  asserts the prompt file is the bundle and that the path it names exists in
  this repository.
- The merge gate in `.github/workflows/ui-review.yml` and the grader in
  `eval/run_eval.py` both read a verdict out of model output that quotes the
  pull request title, body, and diff, all author-controlled. Five defects,
  one family.
  - Both took the first matching line, so a planted `VERDICT: APPROVE`
    reaching column zero in a quoted block decided the merge gate. Section 6
    puts the authoritative verdict last, so both now read the final match.
  - Both accepted any mode's token. The workflow always runs PR mode, so it
    now greps `^VERDICT:` alone, and `MODE_VERDICT_TOKENS` holds the grader
    to the mode each case declares.
  - The gate blocked on `BLOCK` alone. Section 1.8 escalates to
    `NEEDS-HUMAN` where the review cannot establish conformance, and passing
    that green merged the change the review declined to clear.
  - The gate searched the whole verdict line, so the reason decided the
    outcome. It failed closed on
    `VERDICT: APPROVE - resolved earlier BLOCK findings` and failed open on
    `VERDICT: REJECT`, which matched nothing and merged. The gate now reads
    the token and treats an unrecognized one as malformed output. The
    `fail_on_block` input keeps its documented meaning: it governs which
    verdicts block, not whether a non-verdict counts as a pass.
  - `VERDICT_JSON` parsed through a greedy `DOTALL` regex that ran to the
    last brace anywhere in the response. `raw_decode` reads one value and
    ignores what follows.
