# generay

> **Development moved to `abuzucom/agents-personas`.** This repository
> receives no further changes. The generay persona lives in
> [`reviewers/generay/`][moved-persona] there. New callers use
> [`.github/workflows/generay-time-review.yml`][moved-wrapper].
> [`docs/migration.md`][moved-migration] maps the inputs of this
> repository's `time-review.yml`. Existing pins keep working while this
> repository stays available.

[moved-persona]: https://github.com/abuzucom/agents-personas/tree/main/reviewers/generay
[moved-wrapper]: https://github.com/abuzucom/agents-personas/blob/main/.github/workflows/generay-time-review.yml
[moved-migration]: https://github.com/abuzucom/agents-personas/blob/main/docs/migration.md

time is a four sided cube

generay audits time and date handling in code and repositories. It is a
sibling of euler, foucault, adorno, and havel. Time handling looks easy and
fails in ways that tests rarely catch, especially when people or AI write
their own. generay lists those failures as checks and applies them through a
model reviewer backed by deterministic scanners.

## What is in the repository

| Path | Content |
|---|---|
| `TIME.md` | Review prompt for classes C1 to C26. At most 32 KiB. |
| `SYNC.md` | Review prompt for C27, time synchronization. At most 32 KiB. |
| `docs/classes/` | Full draft of each class: facts, code patterns, fixes, escalations. |
| `docs/problems.md` | Notes for PA-1 to PA-155, the problems and bad assumptions. |
| `docs/best-practices.md` | BP-1 to BP-4. |
| `data/ledger.json` | Maps every PA and BP to checks, and every check to its class and method. |
| `data/libraries.json` | Favored-library registry (BP-1), validated by `data/libraries.schema.json`. |
| `scripts/time_checks/` | Deterministic scanners (standard library only). |
| `ci/` | Envelope builder, model client, and report validator. |
| `eval/` | Golden corpus and runner. |

## How a check works

Each check has an ID such as `C7.1` and a method tag.

- `heuristic`: a scanner finds candidates.
- `both`: a scanner finds candidates and the reviewer looks for more.
- `llm`: the reviewer alone.

Scanner hits are candidates. The reviewer confirms or dismisses every one.
No hit blocks on its own.

## Review modes

| Mode | Final line |
|---|---|
| PR | `VERDICT: APPROVE`, `BLOCK`, or `NEEDS-HUMAN` |
| File and Wholesale | `RISK: CRITICAL`, `HIGH`, `MEDIUM`, `LOW`, or `NONE-FOUND` |
| Piece | `RISK (partial): <level>` |
| Contract | `CONTRACT: COMPLETE`, `GAPS`, or `NEEDS-HUMAN` |

Every report ends with a `VERDICT_JSON` line. `TIME.md` defines the schema.

## Commands

- `make check` runs the policy, coverage, registry, scan, eval structure, policy copy, and unit test targets.
- `make sync` regenerates the policy copies after an `AGENTS.md` change.
- `make agents-test`, `make agents-lint`, `make identity`, and `make changelog` run the agents
  checks. Install `requirements-checkers.txt` first.
- `make lint` runs ruff, mypy, and yamllint. Install `requirements-dev.txt` first.
- `python3 scripts/check_time_handling.py all <paths>` runs the scanners.
- `python3 eval/run_eval.py --model-call ci.call_model:call_model` runs the corpus against a model.
  Set `MODEL_API_KEY` outside the repository first.

## Adding content

New problems start at PA-156. Add the note to `docs/problems.md`, merge it into
a class under `docs/classes/`, add its checks to `TIME.md` or `SYNC.md`, and
record it in `data/ledger.json`. `make coverage` fails when these disagree.
New or changed checks ship with an `eval/cases/` case.

## Upstream

Review machinery is copied from `abuzucom/euler`. `upstream-files.json`
records the source path and SHA-256 of each copied file.

Agent policy and tooling come from `abuzucom/agents`. `AGENTS.md` is the
canonical policy. `make sync` regenerates `CLAUDE.md` and the other tool
copies. `docs/project-orientation.md` and `docs/repository-orientation.md`
hold the generay rules and facts. `docs/template-drift.md` records every
difference from the template.
