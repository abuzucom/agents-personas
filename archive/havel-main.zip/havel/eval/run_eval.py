#!/usr/bin/env python3
"""Golden-corpus harness for AUDIT.md.

Validates every case under eval/cases/ against its expected.json. Model
invocation is pluggable: this script never calls a model API directly and
ships no credentials. Point --model-call at a Python callable to run cases
live; omit it to run structure-only (the default), which validates fixture
and expected.json shape without asking a model anything.

Usage:
    python eval/run_eval.py
    python eval/run_eval.py --model-call mymodule:call_model
    python eval/run_eval.py --case keyboard-inaccessible-modal-pr --model-call mymodule:call_model

A --model-call target is a callable with the signature:
    call_model(system_prompt: str, mode: str, case_text: str) -> str
returning the model's raw text response (the human-readable report,
including its final VERDICT:/RISK:/CONFORMANCE: line and, where AUDIT.md
section 6 requires it, the VERDICT_JSON companion block).
"""

from __future__ import annotations

import argparse
import importlib
import importlib.util
import json
import re
import secrets
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
AUDIT_PATH = REPO_ROOT / "AUDIT.md"
CASES_DIR = Path(__file__).resolve().parent / "cases"

VALID_MODES = {"PR", "File", "Piece", "Wholesale", "Data-map"}
CASE_INPUT_NAMES = (
    "diff.patch",
    "input.py",
    "input.ts",
    "input.tsx",
    "input.js",
    "input.sql",
    "input.json",
    "input.yaml",
    "input.tf",
    "input.html",
    "input.md",
    "input.txt",
    "input.sh",
    "datamap.md",
    "ropa.json",
    "notice.md",
)

DECLARED_SCOPE_PREFIX = "DECLARED_SCOPE:"
# Reviewed content sits between these markers. The workflow's Build case text
# step emits the same pair. A fresh nonce on the end marker keeps content from
# closing the frame early.
FRAME_BEGIN = "BEGIN UNTRUSTED CONTENT"
FRAME_END = "END UNTRUSTED CONTENT"
FRAME_NONCE_BYTES = 8
UNDECLARED = "undeclared"
DISCLAIMER_PREFIX = "NOT LEGAL ADVICE:"
VALID_REGIME_SOURCES = {"declared", "elicited", "undeclared"}
DELTA_TOKEN_RE = re.compile(r"^(2\.\d+)@([a-z0-9-]+)$")

VERDICT_LINE_RE = re.compile(
    r"^(VERDICT|RISK(?: \(partial\))?|ACCURACY):\s*(.+)$", re.MULTILINE
)
VERDICT_JSON_PREFIX = "VERDICT_JSON:"

# Section 6 gives each mode one verdict token. Grading a response against the
# wrong one lets a report answering in another mode satisfy a check that mode
# never addressed.
MODE_VERDICT_TOKENS = {
    "PR": "VERDICT",
    "File": "RISK",
    "Wholesale": "RISK",
    "Piece": "RISK (partial)",
    "Data-map": "ACCURACY",
}


class CaseError(Exception):
    pass


_PROFILE_CACHE = None


def _profiles():
    """Return the profile table through the checker, loaded once."""
    global _PROFILE_CACHE
    if _PROFILE_CACHE is None:
        spec = importlib.util.spec_from_file_location(
            "check_regime_refs", REPO_ROOT / "scripts" / "check_regime_refs.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _PROFILE_CACHE = (module, module.load_profiles(REPO_ROOT))
    return _PROFILE_CACHE


def _validate_scope(name: str, expected: dict) -> None:
    """Validate the declared scope and the asserted regime set agree.

    declared_scope is the input side. expected_regimes and
    expected_regime_source are the assertion side. A case asserting a regime
    set beyond the reach of its own declaration is malformed rather than
    failing.
    """
    checker, profiles = _profiles()
    declared = expected.get("declared_scope")
    source = expected.get("expected_regime_source")
    if source is not None and source not in VALID_REGIME_SOURCES:
        raise CaseError(
            f"{name}: expected_regime_source '{source}' is not one of "
            f"{sorted(VALID_REGIME_SOURCES)}. Correct the value.")

    asserted = expected.get("expected_regimes")
    if asserted is not None:
        if not isinstance(asserted, list):
            raise CaseError(
                f"{name}: expected_regimes must be a list of slugs.")
        unknown = sorted(set(asserted) - profiles["slugs"])
        if unknown:
            raise CaseError(
                f"{name}: expected_regimes names unknown {', '.join(unknown)}. "
                "Add each to docs/regimes/scope-profiles.md or correct the case.")

    if declared is not None:
        try:
            reachable = checker.expand_scope(declared, profiles)
        except checker.ScopeError as error:
            raise CaseError(f"{name}: {error}")
        if declared == UNDECLARED and asserted:
            raise CaseError(
                f"{name}: declared_scope is undeclared and expected_regimes is "
                "non-empty. An undeclared scope reaches no regime.")
        if asserted is not None and not set(asserted) <= reachable:
            beyond = sorted(set(asserted) - reachable)
            raise CaseError(
                f"{name}: expected_regimes names {', '.join(beyond)} beyond the "
                f"reach of declared_scope '{declared}'. Widen the declaration or "
                "narrow the assertion.")

    for token in expected.get("expected_classes", []):
        if "@" not in token:
            continue
        match = DELTA_TOKEN_RE.match(token)
        if match is None:
            raise CaseError(
                f"{name}: expected_classes token '{token}' is malformed. "
                "Use the form 2.N@slug.")
        if match.group(2) not in profiles["slugs"]:
            raise CaseError(
                f"{name}: expected_classes token '{token}' names an unknown slug. "
                "Add it to docs/regimes/scope-profiles.md or correct the token.")


def load_case(case_dir: Path) -> dict:
    expected_path = case_dir / "expected.json"
    if not expected_path.is_file():
        raise CaseError(f"{case_dir.name}: missing expected.json")
    expected = json.loads(expected_path.read_text(encoding="utf-8"))

    for key in ("mode", "expected_verdict", "expected_classes", "notes"):
        if key not in expected:
            raise CaseError(f"{case_dir.name}: expected.json missing '{key}'")
    if expected["mode"] not in VALID_MODES:
        raise CaseError(
            f"{case_dir.name}: mode '{expected['mode']}' not one of {sorted(VALID_MODES)}"
        )
    # allow_non_ascii is a structural flag for corpus tests. It does not
    # change harness behavior. A case with non-ASCII fixture content must
    # set allow_non_ascii: true and state the reason in fixture_notes.
    if expected.get("allow_non_ascii") and "fixture_notes" not in expected:
        raise CaseError(
            f"{case_dir.name}: allow_non_ascii: true requires fixture_notes explaining why"
        )

    _validate_scope(case_dir.name, expected)

    input_files = [
        case_dir / name for name in CASE_INPUT_NAMES if (case_dir / name).is_file()
    ]
    if not input_files:
        raise CaseError(f"{case_dir.name}: no recognized input file present")

    context_path = case_dir / "context.md"
    context_text = context_path.read_text(encoding="utf-8") if context_path.is_file() else ""

    case_text = build_case_text(expected, input_files, context=context_text)
    return {
        "name": case_dir.name,
        "mode": expected["mode"],
        "expected": expected,
        "context": context_text,
        "case_text": case_text,
    }


def build_case_text(expected: dict, input_files: list, context: str = "") -> str:
    """Return the case text in the shape the workflow Build case text step emits.

    The DECLARED_SCOPE line opens the text and is the only declaration with
    authority. The context, standing in for a pull request description, and
    every input follow inside the untrusted frame. A scope line planted there
    is reviewed content. A case omitting declared_scope tests the ask branch
    and carries no line.
    """
    parts = [context.strip()] if context.strip() else []
    parts.extend(path.read_text(encoding="utf-8") for path in input_files)
    nonce = secrets.token_hex(FRAME_NONCE_BYTES)
    framed = "\n".join([
        f"{FRAME_BEGIN} {nonce}",
        "\n\n".join(parts).rstrip("\n"),
        f"{FRAME_END} {nonce}",
    ])
    declared = expected.get("declared_scope")
    if declared is None:
        return framed
    return f"{DECLARED_SCOPE_PREFIX} {declared}\n\n{framed}"


def discover_cases(only: str | None = None) -> list[dict]:
    if not CASES_DIR.is_dir():
        raise CaseError(f"cases directory not found: {CASES_DIR}")
    dirs = sorted(p for p in CASES_DIR.iterdir() if p.is_dir())
    if only:
        dirs = [p for p in dirs if p.name == only]
        if not dirs:
            raise CaseError(f"no case named '{only}' under {CASES_DIR}")
    return [load_case(d) for d in dirs]


def verdict_matches(expected_verdict: str, response_text: str, *,
                    mode: str = None) -> tuple[bool, str]:
    """Grade the report's own verdict line against the expected token.

    mode is keyword-only and optional so an existing two-argument call keeps
    working. Where it is given, the response must answer in that mode.
    """
    # A report quotes the diff under review, and a diff is attacker
    # controlled. Section 6 puts the authoritative verdict last, so read the
    # final match rather than a quoted lookalike appearing earlier.
    matches = list(VERDICT_LINE_RE.finditer(response_text))
    if not matches:
        return False, "no VERDICT:/RISK:/ACCURACY: line found in response"
    match = matches[-1]
    actual_line = f"{match.group(1)}: {match.group(2)}".strip()
    required = MODE_VERDICT_TOKENS.get(mode) if mode else None
    if required and match.group(1) != required:
        return False, (f"{mode} mode requires a {required}: line, "
                       f"got '{actual_line}'")
    # Compare against the verdict alone. Searching the whole line lets the
    # reason decide the grade, so an expected BLOCK matched
    # 'VERDICT: APPROVE - no BLOCK conditions observed' and scored a failing
    # case as a pass. Section 6 separates the reason with ' - '.
    severity = match.group(2).split(" - ", 1)[0].strip()
    # Fixtures store the verdict in four shapes: a bare severity ('BLOCK'),
    # the prefixed form ('RISK: MEDIUM'), the prefix alone
    # ('RISK (partial)'), and the prefix with its colon ('RISK:'), which
    # asserts the mode answered without pinning a severity.
    accepted = {
        severity,
        f"{match.group(1)}: {severity}",
        match.group(1),
        f"{match.group(1)}:",
    }
    if expected_verdict in accepted:
        return True, actual_line
    return False, actual_line


def parse_json_companion(response_text: str) -> tuple:
    """Return the last VERDICT_JSON object, or None, and a status message."""
    prefix_at = response_text.rfind(VERDICT_JSON_PREFIX)
    if prefix_at < 0:
        return None, "no VERDICT_JSON: block found"
    brace_at = response_text.find("{", prefix_at)
    if brace_at < 0:
        return None, "VERDICT_JSON block carries no object"
    # raw_decode reads one value and ignores whatever follows. A greedy regex
    # instead runs to the last brace in the report, so the required trailing
    # disclaimer or any later prose carrying a brace breaks the parse.
    try:
        payload, _end = json.JSONDecoder().raw_decode(response_text, brace_at)
    except json.JSONDecodeError as exc:
        return None, f"VERDICT_JSON block did not parse: {exc}"
    return payload, "VERDICT_JSON parsed"


def json_companion_ok(response_text: str) -> tuple[bool, str]:
    payload, detail = parse_json_companion(response_text)
    return payload is not None, detail


def _reported_findings(payload: dict) -> tuple:
    """Return (class, regime set) pairs from the companion, or None and a reason."""
    findings = payload.get("findings") if isinstance(payload, dict) else None
    if not isinstance(findings, list):
        return None, "VERDICT_JSON findings is not a list"
    reported = []
    for finding in findings:
        if not isinstance(finding, dict) or not isinstance(finding.get("class"), str):
            return None, "VERDICT_JSON carries a finding without a string class"
        regime = finding.get("regime", [])
        regimes = regime if isinstance(regime, list) else [regime]
        reported.append((finding["class"], {str(slug) for slug in regimes}))
    return reported, ""


def _token_reported(token: str, reported: list) -> bool:
    """Return whether a 2.N or 2.N@slug token appears among the findings."""
    expected_class, _, slug = token.partition("@")
    return any(found == expected_class and (not slug or slug in regimes)
               for found, regimes in reported)


def _scope_matches(expected: dict, payload: dict) -> tuple:
    """Compare the companion's regimes and regime_source where the case states them."""
    if "expected_regimes" in expected:
        regimes = payload.get("regimes")
        if not isinstance(regimes, list):
            return False, "VERDICT_JSON regimes is not a list"
        actual = sorted(str(slug) for slug in regimes)
        wanted = sorted(expected["expected_regimes"])
        if actual != wanted:
            return False, f"VERDICT_JSON regimes {actual} differ from expected {wanted}"
    source = expected.get("expected_regime_source")
    if source is not None and payload.get("regime_source") != source:
        return False, (f"VERDICT_JSON regime_source '{payload.get('regime_source')}' "
                       f"differs from expected '{source}'")
    return True, ""


def json_assertions_ok(expected: dict, payload: dict) -> tuple[bool, str]:
    """Grade the companion's findings and scope against the case expectation.

    expected_classes is a floor. Every token must appear and extra findings
    pass. A 2.N@slug token needs a 2.N finding whose regime list names the
    slug. Without this a report reaching the right verdict for the wrong
    class, or under a regime the declaration never named, scored a pass.
    """
    reported, reason = _reported_findings(payload)
    if reported is None:
        return False, reason
    missing = [token for token in expected.get("expected_classes", [])
               if not _token_reported(token, reported)]
    if missing:
        return False, f"VERDICT_JSON omits expected class(es) {', '.join(missing)}"
    scope_ok, reason = _scope_matches(expected, payload)
    if not scope_ok:
        return False, reason
    return True, "VERDICT_JSON classes and scope match"


def resolve_model_call(spec: str):
    module_name, _, func_name = spec.partition(":")
    if not module_name or not func_name:
        raise CaseError("--model-call must be in the form module:function")
    sys.path.insert(0, str(REPO_ROOT))
    module = importlib.import_module(module_name)
    return getattr(module, func_name)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", help="run only the named case")
    parser.add_argument(
        "--model-call",
        help="module:function callable invoked as call(system_prompt, mode, case_text) -> str",
    )
    args = parser.parse_args()

    if not AUDIT_PATH.is_file():
        print(f"AUDIT.md not found at {AUDIT_PATH}", file=sys.stderr)
        return 1
    system_prompt = AUDIT_PATH.read_text(encoding="utf-8")

    try:
        cases = discover_cases(args.case)
    except CaseError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if not args.model_call:
        print(f"structure check only: {len(cases)} case(s) validated, no model call configured")
        for case in cases:
            print(f"  ok  {case['name']} (mode={case['mode']})")
        return 0

    model_call = resolve_model_call(args.model_call)

    failures = 0
    for case in cases:
        response = model_call(system_prompt, case["mode"], case["case_text"])
        ok, detail = verdict_matches(case["expected"]["expected_verdict"], response,
                                     mode=case["mode"])
        if ok and DISCLAIMER_PREFIX not in response:
            ok = False
            detail = f"response omits the required {DISCLAIMER_PREFIX} trailing line"
        status = "pass" if ok else "FAIL"
        print(f"  {status}  {case['name']}: expected '{case['expected']['expected_verdict']}', got '{detail}'")
        if not ok:
            failures += 1

        if case["expected"].get("expect_json"):
            payload, json_detail = parse_json_companion(response)
            json_ok = payload is not None
            if json_ok:
                json_ok, json_detail = json_assertions_ok(case["expected"], payload)
            json_status = "pass" if json_ok else "FAIL"
            print(f"  {json_status}  {case['name']} (VERDICT_JSON): {json_detail}")
            if not json_ok:
                failures += 1

    total = len(cases)
    print(f"\n{total - failures}/{total} verdict checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
