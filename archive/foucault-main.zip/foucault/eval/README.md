# Eval harness

Golden-corpus regression tests for `AUDIT.md`. Each case under `cases/` is a
small code sample (or diff) paired with the verdict a careful reviewer
applying `AUDIT.md` should produce. `AGENTS.md` requires a new or updated
case for any change to `AUDIT.md` that affects a verdict, a hard blocker, or
a severity mapping.

## Why this exists

`AUDIT.md` is a system prompt. Nothing about a well-written instruction
document guarantees a model actually follows it. This harness is the
difference between trusting the prompt and checking it: run every case
against a real model call and confirm the verdicts still match after any
edit.

## Model-agnostic by design

`run_eval.py` never calls a model API and ships no credentials. Point it at
a locally supplied callable:

```console
python eval/run_eval.py --model-call mymodule:call_model
```

`call_model(system_prompt, mode, case_text) -> str` loads `AUDIT.md` as the
system prompt, sends `case_text` (the fixture plus any `context.md`) as a
user-turn message, and returns the model's raw text response. Wire it to
whichever provider and model an `AUDIT.md` deployment actually uses. This
repository does not prescribe one.

Model adapters receive a JSON review envelope as `case_text`. The envelope
separates `TRUSTED_HOOK_CONTEXT` from `REVIEW_TARGET`. Hook context is marked
read-only and cannot support a finding. Each channel has a SHA-256 digest over
UTF-8 text. Production deployments must pin `AUDIT.md` outside the reviewed
checkout. Local structure checks do not compare a policy file with a hash
stored beside that same file.

`--model-call` resolves to an importable module and executes its code. Treat
it as a trusted input. Supply it only from a local invocation or a CI
configuration under this repository's control, never from pull request content
or any other value an outside contributor can influence. `ci.yml` never passes
it.

Without `--model-call`, the script runs structure-only. It confirms every
`expected.json` and fixture file parses and is internally consistent, then
exits 0. This is what runs in this repository's own CI, since foucault
ships no model credential. Any consumer with a model credential can run the
live check the same way.

The repository also runs `scripts/check_audit_policy.py`. The checker validates
required sections and controls, duplicate headings, ASCII text, LF endings,
prose width, and the 32 KiB policy limit. Run `make audit-check` to run the
checker, policy-size check, and structure-only corpus together.

The repository's CI adapter lives at `ci.call_model:call_model`. It reads the
active provider profile from `ci/model_providers.json`. Set `MODEL_API_KEY`
outside the repository before running a live check. The adapter supports the
Ollama, OpenAI-compatible, Anthropic, and Google protocols. Provider
endpoints remain restricted to the checked-in allowlist.

Ollama Cloud uses the native `/api/chat` request. Other providers use their
native text-generation request shape. The adapter sends `AUDIT.md` as the
system instruction and the JSON review envelope as the user message. It
returns only the model's text content. The workflow validates both the final
`VERDICT` line and the `VERDICT_JSON` companion.

## Case format

```
eval/cases/<slug>/
  diff.patch | input.<ext>   one or more input files (the review unit)
  context.md                 optional: PR description or ticket text
  hook_context.md            optional trusted runtime context
  expected.json              required
```

`expected.json` fields:

| Field | Meaning |
|---|---|
| `mode` | `PR`, `File`, `Piece`, or `Wholesale` (AUDIT.md section 0) |
| `expected_verdict` | Substring the response's `VERDICT:`/`RISK:` line must contain, e.g. `BLOCK`, `RISK: CRITICAL`, `RISK (partial)` |
| `expected_classes` | AUDIT.md section 2.x references the case exercises |
| `expect_json` | If `true`, the harness also requires a parseable `VERDICT_JSON:` block (AUDIT.md section 6) |
| `expected_review_status` | Optional `REVIEW STATUS` token checked for timeout cases |
| `report_contract` | Optional PR-only checks for narration, prior-finding status, and required cited evidence |
| `notes` | Why this verdict is correct, for a human reviewing the case |
| `fixture_notes` | Optional: provenance of any secret-shaped value in the fixture (see below) |

## Secret-shaped fixtures

A case testing secret detection (`AUDIT.md` 2.3) needs a value with real
entropy, because entropy is the signal the review workflow keys on. `hardcoded-secret-pr` uses a string generated fresh with Python's `secrets`
module for that fixture alone. It has never been a working credential for
any account or service. `AGENTS.md` non-negotiable rule 1 requires this for
every case: synthetic and high-entropy where the case needs entropy,
low-entropy and placeholder-shaped where the case tests the false-positive
rule instead (`clean-*` cases), never copied from a real system.

## Current cases

| Case | Mode | Tests |
|---|---|---|
| `sql-injection-pr` | PR | 2.5, string-concatenated SQL, hard blocker |
| `hardcoded-secret-pr` | PR | 2.3/2.6, committed high-entropy secret, hard blocker |
| `weak-hash-password-file` | File | 2.7, MD5 password hash, hard blocker |
| `missing-authz-idor-pr` | PR | 2.4, IDOR on a data-mutating endpoint, hard blocker |
| `ssrf-file` | File | 2.5, unvalidated server-side fetch |
| `piece-fragment-unseen-caller` | Piece | section 6, never a clean verdict when safety depends on unseen code |
| `clean-parameterized-query-pr` | PR | section 8, a parameterized query is not a finding |
| `clean-file-wholesale` | File | section 9, zero-findings protocol on genuinely clean code |
| `xxe-pr` | PR | 2.5, external entities enabled, hard blocker |
| `ssti-file` | File | 2.5, user input compiled as a template |
| `xss-and-redirect-file` | File | 2.5, DOM sink and a prefix-matched redirect |
| `key-custody-pr` | PR | 2.3, provider key inlined into a browser bundle |
| `second-order-injection-file` | File | 2.5, safe write, unsafe later read |
| `ldap-filter-injection-file` | File | 2.5, query construction outside SQL |
| `upload-validation-pr` | PR | 2.5, extension-only typing into a served path |
| `content-type-switch-file` | File | 2.5, parser chosen by sniffing the body |
| `zip-slip-file` | File | 2.5, archive entry names as an unrecognized source |
| `session-lifecycle-file` | File | 2.4, no rotation, no server-side invalidation |
| `token-validation-file` | File | 2.4/2.7, algorithm confusion and absent claims |
| `delegated-authz-pr` | PR | 2.4, no state, no PKCE, caller-supplied redirect |
| `credential-path-file` | File | 2.4, second factor bypassed by a parallel route |
| `type-coercion-bypass-file` | File | 2.4/2.5, the checked value is not the used value |
| `password-storage-file` | File | 2.7, work factor below floor plus a reversible copy |
| `primitive-strength-file` | File | 2.7, unnamed weak cipher and an undersized key |
| `crypto-construction-file` | File | 2.7, MAC-then-encrypt padding oracle |
| `hmac-timing-compare-file` | File | 2.7, early-return digest comparison |
| `deployment-surface-file` | File | 2.6, directory listing, reachable dotfiles, version banner |
| `error-and-output-leak-file` | File | 2.8/2.12, correct rejection leaking internals |
| `data-lifecycle-file` | File | 2.12, unencrypted at rest, no deletion path, whole-object logging |
| `instruction-channel-pr` | PR | 2.15, system prompt composed from tenant data |
| `agent-trust-propagation-file` | File | 2.15, model output reloaded as fact |
| `rag-provenance-file` | File | 2.15, retrieved chunks with an inverted hierarchy |
| `sandbox-privilege-pr` | PR | 2.6, privileged container with a mounted socket |
| `git-hooks-untrusted-repo-file` | File | 2.6, hooks in a user-supplied repository |
| `sandbox-network-file` | File | 2.6, unrestricted egress and reachable metadata |
| `sandbox-fallback-file` | File | 2.8/2.6, sandbox degrading to host execution |
| `agent-env-inheritance-pr` | PR | 2.6, worker inheriting the full parent environment |
| `agent-hardening-calibration-pr` | PR | section 8, stricter agent controls and matching test expectations are not findings without concrete impact |
| `tool-output-secret-leak-file` | File | 2.15, credentials through the tool boundary |
| `llm-output-to-markdown-file` | File | 2.5/2.15, model output rendered into markdown |
| `no-lockfile-file` | File | 2.1, no lockfile at all |
| `dependency-health-file` | File | 2.1, overlapping, unmaintained and unpinned packages |
| `copyleft-dependency-file` | File | 2.14, copyleft dependency in a proprietary product |
| `deprecated-unsafe-api-file` | File | 2.2, unsafe superseded API with the warning suppressed |
| `lost-update-file` | File | 2.9, read-modify-write with no concurrency check |
| `distributed-lock-pr` | PR | 2.9, scheduled job without a single executor |
| `authz-sweep-wholesale` | Wholesale | section 3, one route of four missing its guard |
| `inapplicable-classes-file` | File | section 3 step 0, classes that do not apply are not findings |
| `dependency-confusion-file` | File | 2.1, internal-sounding package name on a public registry |
| `install-script-pr` | PR | 2.1, download-and-execute in a postinstall script |
| `webhook-no-signature-file` | File | 2.4, payment events acted on without signature verification |
| `websocket-no-origin-file` | File | 2.4, no Origin check and no per-message authorization |
| `csv-formula-injection-file` | File | 2.5, user fields exported into spreadsheet formulas |
| `ci-workflow-injection-pr` | PR | 2.5/2.6, issue title interpolated into a run step with a write-all token |
| `contradictory-logic-file` | File | 2.13, guard placed after the use and a state re-tested after an earlier check ruled it out |
| `host-header-reset-file` | File | 2.4, reset link built from the request Host header |
| `prototype-pollution-file` | File | 2.5, merge helper copying `__proto__` from a request body |
| `graphql-limits-file` | File | 2.11, no depth limit and aliased login mutations |
| `decompression-bomb-file` | File | 2.11, archive extracted with no expansion cap |
| `ambiguous-hook-provenance-pr` | PR | section 7, missing provenance escalates to NEEDS-HUMAN |
| `policy-reinjection-hook-pr` | PR | section 8, repo-controlled policy reinjection is not a finding |
| `rereview-new-defect-pr` | PR | section 3 re-review, a fix commit adds shell interpolation that a resolved prior finding must not clear |
| `report-process-narration-pr` | PR | section 6, omit process narration while retaining a resolved prior finding, cited evidence, and a valid verdict |

The report-contract case checks the production PR response validator. Run the
case against the prompt before and after a prompt change with the same
`--case` and `--model-call` arguments. The harness scores the verdict,
`VERDICT_JSON`, prior-finding status, and required finding location. Structure
checks do not call a model and cannot measure live narration rates.
