#!/usr/bin/env python3
"""Golden-corpus harness for AUDIT.md.

Validates every case under eval/cases/ against its expected.json. Model
invocation is pluggable: this script never calls a model API directly and
ships no credentials. Point --model-call at a Python callable to run cases
live; omit it to run --check-structure only (the default), which validates
fixture and expected.json shape without asking a model anything.

Usage:
    python eval/run_eval.py
    python eval/run_eval.py --model-call mymodule:call_model
    python eval/run_eval.py --case sql-injection-pr --model-call mymodule:call_model

A --model-call target is a callable with the signature:
    call_model(system_prompt: str, mode: str, case_text: str) -> str
returning the model's raw text response (the human-readable report,
including its final VERDICT:/RISK: line and, where AUDIT.md section 6
requires it, the VERDICT_JSON companion block).
"""

from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import re
import sys
from collections.abc import Callable
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.check_pr_review_response import (
    PRIOR_FINDING_STATUS_PATTERN,
    VERDICT_JSON_KEYS,
    VERDICT_JSON_PREFIX,
    ResponseError,
    parse_verdict_json_line,
    valid_line_number,
    validate_response,
)

AUDIT_PATH = REPO_ROOT / "AUDIT.md"
CASES_DIR = Path(__file__).resolve().parent / "cases"

VALID_MODES = {"PR", "File", "Piece", "Wholesale"}
CASE_INPUT_NAMES = ("diff.patch", "input.py", "input.txt", "input.js")

VERDICT_LINE_RE = re.compile(
    r"^(VERDICT|RISK(?: \(partial\))?):\s*(.+)$", re.MULTILINE
)
# Section 6 gives each mode one verdict token. Grading a response against the
# wrong one lets a report answering in another mode satisfy a check that mode
# never addressed. File and Wholesale make no merge claim at all.
MODE_VERDICT_TOKENS = {
    "PR": "VERDICT",
    "File": "RISK",
    "Wholesale": "RISK",
    "Piece": "RISK (partial)",
}


class CaseError(Exception):
    """Report a malformed or missing eval case under eval/cases/."""


def normalize_text(text: str) -> bytes:
    """Return the canonical bytes used for provenance hashes."""
    return text.replace("\r\n", "\n").encode("utf-8")


def sha256_text(text: str) -> str:
    """Return the SHA-256 digest of canonical text bytes."""
    return hashlib.sha256(normalize_text(text)).hexdigest()


def build_review_envelope(case: dict, system_prompt: str) -> dict:
    """Build separately labeled, read-only model inputs."""
    target = case["context"] + "\n\n" + case["case_text"]
    hook_context = case.get("hook_context", "")
    if case["expected"].get("omit_provenance"):
        return {"mode": case["mode"], "text": target}
    return {
        "mode": case["mode"],
        "TRUSTED_HOOK_CONTEXT": {
            "read_only": True,
            "sha256": sha256_text(hook_context),
            "text": hook_context,
        },
        "REVIEW_TARGET": {
            "sha256": sha256_text(target),
            "text": target,
        },
        "policy_sha256": sha256_text(system_prompt),
    }


def load_case(case_dir: Path) -> dict:
    """Return one validated case, raising CaseError for a malformed case."""
    expected_path = case_dir / "expected.json"
    if not expected_path.is_file():
        raise CaseError(f"{case_dir.name}: missing expected.json")
    try:
        expected = json.loads(expected_path.read_text(encoding="utf-8"))
    except ValueError as error:
        raise CaseError(
            f"{case_dir.name}: expected.json is not valid UTF-8 JSON ({error})"
        ) from error
    if not isinstance(expected, dict):
        raise CaseError(f"{case_dir.name}: expected.json is not an object")

    for key in ("mode", "expected_verdict", "expected_classes", "notes"):
        if key not in expected:
            raise CaseError(f"{case_dir.name}: expected.json missing '{key}'")
    if expected["mode"] not in VALID_MODES:
        raise CaseError(
            f"{case_dir.name}: mode '{expected['mode']}' not one of {sorted(VALID_MODES)}"
        )
    if (
        "expected_review_status" in expected
        and expected["expected_review_status"] != "NEEDS-HUMAN"
    ):
        raise CaseError(
            f"{case_dir.name}: expected_review_status must be NEEDS-HUMAN"
        )
    if "report_contract" in expected:
        _validate_report_contract(case_dir.name, expected)

    input_files = [
        case_dir / name for name in CASE_INPUT_NAMES if (case_dir / name).is_file()
    ]
    if not input_files:
        raise CaseError(f"{case_dir.name}: no recognized input file present")

    context_path = case_dir / "context.md"
    context_text = context_path.read_text(encoding="utf-8") if context_path.is_file() else ""
    hook_path = case_dir / "hook_context.md"
    hook_context = hook_path.read_text(encoding="utf-8") if hook_path.is_file() else ""

    case_text = "\n\n".join(p.read_text(encoding="utf-8") for p in input_files)
    return {
        "name": case_dir.name,
        "mode": expected["mode"],
        "expected": expected,
        "context": context_text,
        "case_text": case_text,
        "hook_context": hook_context,
    }


def _validate_report_contract(case_name: str, expected: dict) -> None:
    """Validate optional PR report requirements in one case."""
    contract = expected["report_contract"]
    if expected["mode"] != "PR" or expected.get("expect_json") is not True:
        raise CaseError(
            f"{case_name}: report_contract requires a JSON-enabled PR case"
        )
    if not isinstance(contract, dict):
        raise CaseError(f"{case_name}: report_contract must be an object")
    if set(contract) != {
        "forbid_process_narration",
        "require_prior_finding_status",
        "required_finding",
    }:
        raise CaseError(f"{case_name}: report_contract has an invalid shape")
    if contract.get("forbid_process_narration") is not True:
        raise CaseError(
            f"{case_name}: report_contract must forbid process narration"
        )
    if contract.get("require_prior_finding_status") is not True:
        raise CaseError(
            f"{case_name}: report_contract must require prior finding status"
        )
    finding = contract.get("required_finding")
    if not isinstance(finding, dict) or set(finding) != {"class", "file", "line"}:
        raise CaseError(f"{case_name}: required_finding has an invalid shape")
    expected_classes = expected["expected_classes"]
    if not isinstance(expected_classes, list):
        raise CaseError(f"{case_name}: expected_classes must be a list")
    if not isinstance(finding["class"], str) or finding["class"] not in expected_classes:
        raise CaseError(
            f"{case_name}: required_finding class must appear in expected_classes"
        )
    if not isinstance(finding["file"], str) or not finding["file"]:
        raise CaseError(f"{case_name}: required_finding file is invalid")
    if not valid_line_number(finding["line"]):
        raise CaseError(f"{case_name}: required_finding line is invalid")


def discover_cases(only: str | None = None) -> list[dict]:
    if not CASES_DIR.is_dir():
        raise CaseError(f"cases directory not found: {CASES_DIR}")
    dirs = sorted(p for p in CASES_DIR.iterdir() if p.is_dir())
    if only:
        dirs = [p for p in dirs if p.name == only]
        if not dirs:
            raise CaseError(f"no case named '{only}' under {CASES_DIR}")
    return [load_case(d) for d in dirs]


def verdict_matches(expected_verdict: str, response_text: str, *,
                    mode: str | None = None) -> tuple[bool, str]:
    """Grade the report's own verdict line against the expected token.

    mode is keyword-only and optional so an existing two-argument call keeps
    working. Where it is given, the response must answer in that mode.
    """
    # A report quotes the diff under review, and a diff is attacker
    # controlled. Section 6 puts the authoritative verdict last, so read the
    # final match rather than a quoted lookalike appearing earlier.
    matches = list(VERDICT_LINE_RE.finditer(response_text))
    if not matches:
        return False, "no VERDICT:/RISK: line found in response"
    match = matches[-1]
    actual_line = f"{match.group(1)}: {match.group(2)}".strip()
    required = MODE_VERDICT_TOKENS.get(mode) if mode else None
    if required and match.group(1) != required:
        return False, (f"{mode} mode requires a {required}: line, "
                       f"got '{actual_line}'")
    # Compare against the verdict alone. Searching the whole line lets the
    # reason decide the grade, so an expected BLOCK matched
    # 'VERDICT: APPROVE - no BLOCK conditions observed' and scored a failing
    # case as a pass. Section 6 separates the reason with ' - '.
    severity = match.group(2).split(" - ", 1)[0].strip()
    # Fixtures store the verdict in four shapes: a bare severity ('BLOCK'),
    # the prefixed form ('RISK: MEDIUM'), the prefix alone
    # ('RISK (partial)'), and the prefix with its colon ('RISK:'), which
    # asserts the mode answered without pinning a severity.
    accepted = {
        severity,
        f"{match.group(1)}: {severity}",
        match.group(1),
        f"{match.group(1)}:",
    }
    return expected_verdict in accepted, actual_line


def review_status_matches(expected_status: str, response_text: str) -> bool:
    """Return whether the report's final review status line matches.

    A report quotes earlier review status lines, and each carries an
    untrusted origin at grading time. The last REVIEW STATUS line is the
    report's own conclusion, so it decides the grade the way the final
    verdict line does.
    """
    prefix = f"REVIEW STATUS: {expected_status}"
    lines = [
        line
        for line in response_text.splitlines()
        if line.startswith("REVIEW STATUS:")
    ]
    if not lines:
        return False
    return lines[-1].startswith(prefix)


def json_companion_ok(response_text: str) -> tuple[bool, str]:
    """Return whether the last VERDICT_JSON line has the section 6 shape.

    Unlike the CI validator, this check accepts every review mode and does
    not require the line to follow the verdict line.
    """
    for line in reversed(response_text.splitlines()):
        if not line.startswith(VERDICT_JSON_PREFIX):
            continue
        try:
            result = parse_verdict_json_line(line)
        except ResponseError as error:
            return False, f"VERDICT_JSON block did not parse: {error}"
        if set(result) != VERDICT_JSON_KEYS:
            return False, "VERDICT_JSON block has an invalid shape"
        if result["mode"] not in VALID_MODES or not isinstance(result["verdict"], str):
            return False, "VERDICT_JSON block has invalid values"
        if not isinstance(result["findings"], list):
            return False, "VERDICT_JSON findings are not a list"
        return True, "VERDICT_JSON parsed"
    return False, "no VERDICT_JSON: line found"


def report_contract_result(expected: dict, response_text: str) -> tuple[bool, str]:
    """Score narration, prior-finding status, and required finding evidence."""
    contract = expected.get("report_contract")
    if not contract:
        return True, "no additional report contract"
    try:
        _verdict, payload = validate_response(response_text)
    except (ResponseError, UnicodeError) as error:
        return False, f"invalid PR report: {error}"

    failures = []
    if not PRIOR_FINDING_STATUS_PATTERN.search(response_text):
        failures.append("prior finding status is absent")
    required = contract["required_finding"]
    has_finding = any(
        finding.get("class") == required["class"]
        and finding.get("file") == required["file"]
        and finding.get("line") == required["line"]
        for finding in payload["findings"]
    )
    if not has_finding:
        failures.append("required finding evidence is absent")
    if failures:
        return False, "; ".join(failures)
    return True, "report contract passed"


def resolve_model_call(spec: str) -> Callable[[str, str, str], str]:
    """Return the callable a module:function --model-call spec names."""
    module_name, _, func_name = spec.partition(":")
    if not module_name or not func_name:
        raise CaseError("--model-call must be in the form module:function")
    sys.path.insert(0, str(REPO_ROOT))
    module = importlib.import_module(module_name)
    return getattr(module, func_name)


def main() -> int:
    """Validate every case and grade model responses when configured."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", help="run only the named case")
    parser.add_argument(
        "--model-call",
        help="module:function callable invoked as call(system_prompt, mode, case_text) -> str",
    )
    args = parser.parse_args()

    if not AUDIT_PATH.is_file():
        print(f"AUDIT.md not found at {AUDIT_PATH}", file=sys.stderr)
        return 1
    system_prompt = AUDIT_PATH.read_text(encoding="utf-8")
    try:
        cases = discover_cases(args.case)
    except CaseError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if not args.model_call:
        print(f"structure check only: {len(cases)} case(s) validated, no model call configured")
        for case in cases:
            print(f"  ok  {case['name']} (mode={case['mode']})")
        return 0

    model_call = resolve_model_call(args.model_call)

    failures = 0
    checks = len(cases)
    for case in cases:
        envelope = build_review_envelope(case, system_prompt)
        response = model_call(
            system_prompt,
            case["mode"],
            json.dumps(envelope, ensure_ascii=True, sort_keys=True),
        )
        ok, detail = verdict_matches(case["expected"]["expected_verdict"], response,
                                     mode=case["mode"])
        status = "pass" if ok else "FAIL"
        print(f"  {status}  {case['name']}: expected '{case['expected']['expected_verdict']}', got '{detail}'")
        if not ok:
            failures += 1

        expected_status = case["expected"].get("expected_review_status")
        if expected_status is not None:
            checks += 1
            status_ok = review_status_matches(expected_status, response)
            status = "pass" if status_ok else "FAIL"
            print(f"  {status}  {case['name']} (REVIEW STATUS)")
            if not status_ok:
                failures += 1

        if case["expected"].get("expect_json"):
            checks += 1
            json_ok, json_detail = json_companion_ok(response)
            json_status = "pass" if json_ok else "FAIL"
            print(f"  {json_status}  {case['name']} (VERDICT_JSON): {json_detail}")
            if not json_ok:
                failures += 1

        if case["expected"].get("report_contract"):
            checks += 1
            report_ok, report_detail = report_contract_result(
                case["expected"], response
            )
            report_status = "pass" if report_ok else "FAIL"
            print(
                f"  {report_status}  {case['name']} (report contract): "
                f"{report_detail}"
            )
            if not report_ok:
                failures += 1

    print(f"\n{checks - failures}/{checks} response checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
