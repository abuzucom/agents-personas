#!/usr/bin/env python3
"""Tests for repository-only and adoptable policy content."""
import sys
import unittest
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
POLICY_PATH = REPO_ROOT / "AGENTS.md"
sys.path.insert(0, str(REPO_ROOT / "scripts"))

import sync


class AdoptablePolicyTest(unittest.TestCase):
    """Adoption excludes source-repository orientation."""

    def test_filter_removes_repository_only_block(self):
        source = (
            "before\n"
            f"{sync.REPOSITORY_ONLY_START}\n"
            "local facts\n"
            f"{sync.REPOSITORY_ONLY_END}\n"
            "after\n"
        )
        self.assertEqual(sync.adoptable_content(source), "before\nafter\n")

    def test_filter_rejects_unbalanced_markers(self):
        source = f"before\n{sync.REPOSITORY_ONLY_START}\nlocal facts\n"
        with self.assertRaises(ValueError):
            sync.adoptable_content(source)

    def test_live_policy_omits_repository_only_block(self):
        policy = POLICY_PATH.read_text(encoding="utf-8")
        self.assertEqual(policy.count(sync.REPOSITORY_ONLY_START), 0)
        self.assertEqual(policy.count(sync.REPOSITORY_ONLY_END), 0)

    def test_adoptable_policy_keeps_local_policy(self):
        policy = POLICY_PATH.read_text(encoding="utf-8")
        adoptable = sync.adoptable_content(policy)
        self.assertIn("## Foucault product rules", adoptable)
        self.assertNotIn("## Repository-only orientation", adoptable)


if __name__ == "__main__":
    unittest.main()
