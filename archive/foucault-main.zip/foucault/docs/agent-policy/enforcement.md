# Enforcement

Repository hooks provide defense in depth. Repository writers can modify them.
Tamper resistance requires an external harness, filesystem isolation, or
server-side controls.

Adopt every gate with its registrations, shared modules, tests, and checkers.
Missing artifacts indicate incomplete adoption. Complete the adoption and run
the recovery check.

The gates refuse destructive commands, unsafe infrastructure access, direct
GitHub CLI lookup, unsafe GitHub HTTP substitutes, credential-manager access,
browser token recovery, and incomplete policy loading.

The gates route consent-required acts to the active human. Unattended sessions
refuse those acts.

Designed denials, prompts, refusals, opaque-command blocks, and exit code 2 on
missing shared modules are policy outcomes. They are not defects.

Run:

- `python scripts/check_gate_adoption.py`
- `python scripts/check_hook_launchers.py`
- `python scripts/check_hook_coverage.py`
- `python scripts/sync.py --check-shared`
- `python -m unittest tests.test_gate_parity -v`

The checks cover only observed files, commands, clients, and event surfaces.
External controls must enforce controls beyond repository coverage.

Hooks must not label execution as elevated without a client runtime approval
result. Missing or contradictory approval metadata fails closed. Repository
hooks cannot inspect client prose when the client API hides it. An external
harness must enforce those claims.

Executable changes require a behavioral test. The test-first checker examines
changed pull request paths and staged paths. Documentation-only changes remain
outside that check.

GitHub wrapper audits must verify both gates. The first gate evaluates the
caller-supplied arguments. The second gate evaluates the final vector after
repository context injection. Tests must cover explicit target preservation,
global options, option termination, linked worktrees, detached heads, malformed
remotes, proxy filtering, token denial, and sanitized diagnostics.

The wrapper must preserve Foucault-specific protections when upstream changes
remove them. Those protections include token-output denial, attached body text
escape detection, bounded output, and safe exception reporting.

The complete adoption inventory and recovery procedure cover every hook,
registration, shared module, test, checker, manifest, policy file, and
synchronized copy. A designed-denial defect report includes the exact input,
contradictory policy text, and a reproduction. Report a blocked file, command,
and message. A blocking gate does not authorize another act.

Use a CI job, pre-commit hook, or script for mechanically checkable rules.
State the limitation for rules that require human semantic review.

Policy inputs use LF line endings. The policy-size checker rejects CRLF bytes
before accepting the file. Script subprocesses decode text as UTF-8 with
replacement handling. This keeps diagnostics usable when Git or GitHub CLI
emits bytes that the Windows system codec cannot decode.

The destructive gate set includes the Bash, PowerShell, CMD, shared parser,
platform policy, shared gate, and parity-test files. Register Bash, PowerShell,
and available CMD `PreToolUse` matchers. Require matching Git and destructive
verdicts across all shell gates.

`scripts/check_banned_agents.py` checks authors, committers,
`Co-authored-by` trailers, and pull request authors. It cannot identify hidden
agent use under a human identity. Platform controls apply separately.

`AGENTS.md` controls when linked documents conflict with it.

Claude Code's consent hook reads paths. New test files do not prompt. Existing
test edits prompt. A final `ExistingTest = None` assignment can disable a
textual implementation. The Bash gate also protects existing tests reached by
redirects, `tee`, `sed -i`, `cp`, or `mv`.

Adopt the consent hook with `hooks/require_consent.py`, `hooks/_gate_core.py`,
its test, and the `.claude/settings.json` `PreToolUse` registration for
`Edit|Write|MultiEdit|NotebookEdit`. Adopt the matching Bash protection. Do not
adopt one gate without the other.
