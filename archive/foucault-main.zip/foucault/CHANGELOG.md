# Changelog

This file documents every notable project change.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project follows Semantic Versioning. Pin a tag or commit SHA when
loading `AUDIT.md` into a deployment.

## [3.8.10] (2026-11-24)

### Changed
- Announce the move to `abuzucom/agents-personas` at the top of the
  README. The foucault persona continues there under `reviewers/foucault/`.
  This repository receives no further changes.

## [3.8.9] (2026-11-15)

### Fixed

- A cancelled security review run now publishes a `cancelled`
  `security-review` check. The old check reported `failure` with the
  text for a review that failed before a verdict. A newer run for the
  same head cancels the older run through the concurrency group. The
  cancelled check never carries a verdict. A run cancelled after the
  verdict parse also drops its verdict line. The caller still schedules a
  review. A check publication error on a cancelled run logs a warning.
  The status lookup reads only own properties. An unknown job status
  maps to `failure`.

### Added

- Added `tests/test_review_cancelled_check.py`. The test executes the
  `Publish check run` script under node for each job status.

## [3.8.8] (2026-11-15)

### Fixed

- A security review that ends without a `VERDICT` line now posts a pull
  request comment. The comment carries the fenced model response and the
  workflow run link. An empty response posts a fixed failure notice. The
  shown response shrinks to fit both backtick fences within the GitHub comment
  limit. A long backtick run therefore cannot block the comment. The new
  `security-review.yml` step runs only on a failure with an empty verdict
  output. A `BLOCK` verdict keeps its single comment. The `security-review`
  check still fails, and the merge gate stays closed.

### Added

- Added `tests/test_review_failure_comment.py`. The test executes the new
  step script under node.

## [3.8.7] (2026-11-15)

### Security

- Replaced terminal control characters in `gh` stdout in
  `scripts/trusted_gh.py`. Stderr already passed through the same filter.
  Titles, bodies, and comments from other accounts reach stdout. An escape
  sequence there could rewrite the terminal or its title. Tabs and line
  breaks stay unchanged.
- Extended the weak-hash and secret checkers to `hooks/`, `eval/*.py`, and
  `tools/` in CI and pre-commit. CI enables bash `globstar`. The
  `hooks/**/*.py` and `tools/**/*.py` patterns then reach every directory
  depth, the same scope as the pre-commit regexes. The CI secret step also
  scans `.pre-commit-config.yaml`.
  `eval/cases/` stays out because its fixtures hold intentional findings.
- Ran the three PyYAML pre-commit hooks as `language: system`. Pre-commit
  previously installed PyYAML into its own environment without hash
  verification. The hooks now use the Python that installed
  `requirements-checkers.txt` in pip hash-checking mode.

### Added

- Added `tests/test_adapted_security_notes.py`.

## [3.8.6] (2026-11-15)

### Changed

- The CI "Prose style" step runs `make lint PYTHON=python3`. The Makefile
  `PROSE_FILES` list is the single prose file list. It adds
  `docs/pr-quality-review.md` and `docs/pr-security-review.md`. CI now also
  checks the five `docs/agent-policy/` pages. `make lint` runs the blocking
  `check_ascii.py` check. The shell loop and its shellcheck suppression are
  gone.
- Pinned `actions/setup-python` to Python 3.14 in `ci.yml`,
  `scheduled-validation.yml`, and `immutable-conflict-check.yml`. CI
  resolved `3.x` to 3.14.10 on every runner. The trusted compliance schema
  accepts a pinned minor version.
- Added release comments to the three action pins in
  `immutable-conflict-check.yml`.
- Dropped the always-empty `github.event.pull_request.head.sha` term from the
  `security-review-pr.yml` concurrency group. A `workflow_run` event carries
  no pull request payload.
- Renamed the inner `matches` constant in `quality-review-pr.yml` to
  `workflowRuns`. The outer `matches` constant no longer shares its name.
- The `model_call_command` input description in `security-review.yml` states
  the two-word `python` or `python3` and `.py` contract. The input name, type,
  and requirement stay unchanged.
- Corrected the `ci.yml` header. The header names `actions/setup-python` and
  the hash-checked PyYAML install.

### Added

- Added `tests/test_workflow_quality_wiring.py`.

## [3.8.5] (2026-11-15)

### Changed

- Moved the euler quality review pin in `quality-review-pr.yml` from euler
  0.7.1 to 0.9.0 (`940c53a`). The quality review now runs
  `minimax-m3.1-flash` and reviews most pull requests in one model call.
  Euler 0.7.1 ran `kimi-k2.7-code`. Euler 0.9.0 keeps the same workflow
  inputs, job permissions, and check run titles.
- `docs/pr-quality-review.md` names `minimax-m3.1-flash` as the active
  profile of the pinned euler revision.

## [3.8.4] (2026-11-15)

### Fixed

- Reported a `"shared"` value in `shared-files.json` that is not a JSON
  object in `sync.py --check-shared`. A list or string under that key raised
  `TypeError`. The finding reads
  `"shared" in shared-files.json is not a JSON object`.

### Added

- Added `tests/test_sync_manifest_shape.py`. The tests cover a list and a
  string under the `"shared"` key.

## [3.8.3] (2026-11-15)

### Fixed

- Reported a missing `EVENT_PATH` in `ci/build_pr_case.py` as a case
  construction failure with exit code 1. The script raised `KeyError` with a
  traceback.
- Rejected an invalid `max_output_tokens` provider value in
  `ci/call_model.py` with `ProviderError`. Zero, negative, Boolean, string,
  and float values reached the provider request unchecked. The default stays
  8192 tokens.
- Reported a malformed or non-object `expected.json` in `eval/run_eval.py` as
  a `CaseError` naming the case. The harness raised `JSONDecodeError`.

### Changed

- Exported `parse_verdict_json_line`, `valid_line_number`,
  `VERDICT_JSON_PREFIX`, and `VERDICT_JSON_KEYS` from
  `scripts/check_pr_review_response.py`. `eval/run_eval.py` parses the
  VERDICT_JSON line and validates finding line numbers with those helpers. The
  evaluator and the CI validator now share one implementation. Validator
  messages stay unchanged.
- Replaced the four copies of the diff process cleanup in
  `ci/build_pr_case.py` with one `_terminate_reader` helper. Named the
  metadata timeout, the reader grace period, the model name limit, and the
  default output budget.

### Added

- Added `tests/test_review_adapter_quality.py` with behavioral tests for
  each fix and for the shared parser.

## [3.8.2] (2026-11-14)

### Changed

- `scripts/sync.py` no longer accepts positional arguments, abbreviated
  flags, or more than one mode flag. Each call takes no argument or one of
  `--check`, `--check-shared`, `--write-shared`, and `--print-adoptable`. Every caller in the Makefile,
  CI, pre-commit, and the policy documents uses one of those forms.
- `claim_errors` in `scripts/delivery_evidence.py` returns a different error
  set for primary branches. A `main` or `master` checkout reports
  `current branch is a primary branch`. A branch that differs from the
  remote ref still reports `current branch does not match remote ref`. A
  `main` checkout pushing to `main` previously reported only the mismatch
  error.

### Fixed

- Reported an unversioned staged changelog in `scripts/check_changelog.py`
  instead of raising `TypeError`. A staged `## [Unreleased]` changelog after
  a versioned `HEAD` now prints the findings and exits 1. The missing
  version heading is the only version finding for that case.
- Rejected unknown arguments in `scripts/sync.py` with exit code 2. A
  misspelled `--check` previously fell through to the write mode and
  rewrote the policy copies. The four documented modes stay unchanged.
- Reported a `shared-files.json` manifest that is not a JSON object instead
  of raising `AttributeError` in `sync.py --check-shared`.
- Named the assembled policy bundle in the `sync.py` size error. The error
  previously blamed `AGENTS.md` alone.
- Rejected delivery claims from `master` as well as `main` in
  `scripts/delivery_evidence.py`.
- Rejected an `AUDIT.md` of exactly 32768 bytes in
  `scripts/check_audit_policy.py`. Product rule 4 requires the file to stay
  below that size. The finding reads
  `policy must be smaller than 32768 bytes`.
- Required `scripts/branch_name_bans.txt` in `scripts/check_gate_adoption.py`.
  `check_branch_name.py` treats an absent list as empty. A partial copy
  therefore dropped the vulgarity check without a report.
- Reported an empty or comment-only `scripts/branch_name_bans.txt` in
  `scripts/check_gate_adoption.py`. The finding reads
  `scripts/branch_name_bans.txt lists no banned tokens`. A list without
  tokens disabled the vulgarity check like an absent list.

### Added

- Added `tests/test_checker_crash_handling.py` with behavioral tests for each
  fix.

## [3.8.1] (2026-11-14)

### Removed

- Removed the unused `ollama` profile for `kimi-k2.7-code` from
  `ci/model_providers.json`. That model broke the report format contract on
  every observed review. No route selected it after v3.7.12.
- Removed the shipped `large_input_provider` key. It named the active
  profile. That profile already holds the largest configured context. An
  oversized review still exits with code 3 and records `NEEDS-HUMAN`. The
  adapter keeps its routing code for adopter registries that set the key.

## [3.8.0] (2026-11-14)

### Added

- Added `ci/build_retry_case.py`. A response that fails validation now
  retries with the validator problems in `TRUSTED_HOOK_CONTEXT`. Only
  allowlisted validator messages pass. Any other line becomes a fixed
  placeholder. `REVIEW_TARGET` stays byte-identical. The retry previously resent the
  same envelope, and the model repeated the same format failure.

### Changed

- The "Run model call" step in `security-review.yml` captures the validator
  output and runs the retry on `retry_case.txt`. The step still makes at
  most two model calls.

## [3.7.16] (2026-11-14)

### Changed

- `_git_config_path` in `scripts/trusted_gh.py` reads a worktree pointer
  through `_git_dir`. The two functions previously carried separate copies
  of the pointer parser. Error messages and resolved paths stay unchanged.
- Named the repository discovery limit `MAX_PARENT_SEARCH_DEPTH` in
  `trusted_gh.py`. The limit stays 100 parent directories.

### Added

- Added `tests/test_trusted_gh_worktree.py`. The tests cover linked worktree
  config resolution, matching pointer errors in both readers, and the
  discovery limit.

## [3.7.13] (2026-11-13)

### Fixed

- Treat an HTTP 400 from the model provider as context overflow only when
  the response body names the context or token limit. `ci/call_model.py`
  reads at most 4096 body bytes and never logs them. Any other 400 now fails
  the review on the active model. A plain 400 no longer sends the private
  diff to the large-input model. HTTP 413 still reroutes. Each marker names
  a context or prompt limit. A bare field name such as `token count` does not
  match. The Ollama `context size` wording matches.
- Accept impersonal report lines such as `i.e. the diff adds a test.`,
  `Trace: base to sink is parameterized.`, and `Inspect results: none.` in
  `scripts/check_pr_review_response.py`. A bare `i` or `we` opener followed
  by a period no longer counts as narration. The standalone `trace`,
  `inspect`, and `need to` openers no longer count either. First-person
  narration with those verbs stays rejected.

### Changed

- Send an overflow body with the HTTP 400 in four tests in
  `tests/test_oversized_review_routing.py`. The assertions stay unchanged.
  The active human approved the test change.

### Added

- Add `tests/test_review_adapter_portable.py`. The file imports only `ci/`
  and `scripts/` modules. Adopting repositories copy it with the review
  scripts. It covers profile selection, HTTP 400 and 413 routing, the
  capacity exit code, the bounded diff read, and the narration boundary.

## [3.7.12] (2026-11-13)

### Fixed

- Switched the active review profile to `ollama-large`. That profile runs
  `minimax-m3.1-flash`. `kimi-k2.7-code` broke the report format contract on
  every observed review. Its reports bolded the `VERDICT` line, fenced
  `VERDICT_JSON`, and narrated the review process. The response validator
  rejected each report, and the blind retry repeated the defect.

### Added

- A test that pins the shipped registry's active model.

## [3.7.11] (2026-11-13)

### Fixed

- Dropped relative `PATH` entries in the `scripts/check_compliance_tree.py`
  Git search path. A relative entry resolved against the working directory
  and reached the Git lookup. The filter now strips double quotes before the
  absolute-path test. Both rules match `scripts/trusted_git.py`.
- Failed `check_compliance_tree.py` closed with a named error when the
  attribution checker is absent. The scanner previously skipped attribution
  checks for a checkers mapping without that module.
- Chose the Git process directory in `check_compliance_tree.py` from
  `tempfile.gettempdir()` before the Git executable's directory. An unset
  `TEMP` previously became the current directory.

### Changed

- Removed an impossible guard in `check_compliance_tree.py`. `Popen` with
  `stdout=PIPE` always sets `stdout`.
- Named the BOM-less UTF-16 and UTF-32 detection ratios, the trusted
  workflow step count, the Python setup step index, and the checkout fetch
  depth in `check_compliance_tree.py`.

### Added

- Added `tests/test_compliance_tree_helpers.py`. The tests hold the scanner's
  PATH and directory helpers to the `trusted_git.py` results.

## [3.7.7] (2026-11-12)

### Fixed

- Authenticated the pull request head fetch in `security-review.yml` for a
  head in the base repository. The checkout persists no credential, and a
  private caller failed the fetch with a missing-username error. The step
  now passes the workflow token to that one `git fetch` through
  `GIT_CONFIG_*` environment variables. Git config and the argument vector
  never hold the token. A fork URL fetch receives no credential. The
  workflow inputs stay unchanged.

### Changed

- Narrowed `test_head_fetch_does_not_forward_global_bearer_header` in
  `tests/test_pr_review_integration.py`. The test now requires the
  host-scoped header key and still forbids the unscoped key. Release 3.1.4
  removed every bearer header from the head fetch. The active human approved
  the test change.

### Added

- Added `tests/test_review_head_fetch_credential.py`. The tests execute the
  fetch step script against a recording `git` stand-in.

## [3.7.6] (2026-11-09)

### Changed

- Advanced the `abuzucom/euler` quality review pin from release 0.6.6 at
  commit `368c3260cfd1b4154b8418de920c6d68f28e4db7` to release 0.7.1 at
  commit `eb97d1fe7bfbfec97997a30846f78a57a6f2f2e3`. Release 0.7.0 adds
  investigation efficiency and timeout rules to `QUALITY.md`. Release 0.7.1
  bumps the pinned actions inside the reusable workflow. The reusable
  workflow keeps the input contract and the check name. The caller comments
  record release 0.7.1.

## [3.7.5] (2026-11-09)

### Fixed

- Stated the verdict adjacency explicitly in the fixed report format
  contract. The first suffix-carrying review run removed the narration
  failures and failed on a blank line or fence between the verdict and JSON
  companion lines.

## [3.7.4] (2026-11-09)

### Changed

- Updated `README.md` with the open-head resolution rule, the report format
  contract, and the quality review caller.
- Renumbered the event flow in `docs/pr-security-review.md`.

## [3.7.3] (2026-11-09)

### Fixed

- Appended a fixed report format contract to the review system prompt. Ten
  consecutive review runs failed the response validator on first-person
  report openers, and the contract now states the impersonal report shape in
  the trusted system channel.

## [3.7.2] (2026-11-09)

### Fixed

- Required an open pull request before the PR security review resolves its
  head. Post-merge events such as a compliance re-run, an edited description,
  or a label now fail resolution instead of starting a review on a merged
  head.

## [3.7.1] (2026-11-08)

### Fixed

- Required timeout status lines in every audit mode, including PR mode.
- Prevented duplicate same-head quality reviews and bounded forwarded PR bodies.
- Graded the final `REVIEW STATUS` line in the eval harness so a quoted lookalike cannot decide the grade.
- Allowed a same-head re-review after a quality review ended without a verdict.
- Scoped the reviewed-head marker to check runs published by the GitHub Actions app.

## [3.7.0] (2026-11-07)

### Added

- Added investigation efficiency and timeout guidance to `AUDIT.md`.
- Added trusted timer input and timeout report checks to the eval harness.

## [3.6.1] (2026-11-01)

### Added

- Added a pull request quality review that runs the `abuzucom/euler` review
  beside the security review. The caller gates the review on a successful
  `ci` run and a successful `Immutable Compliance` run for the same head
  revision, and the fork path waits for the `safe-to-review` label and the
  protected `fork-review` environment.
- Added `docs/pr-quality-review.md` with the event flow, the trust
  boundary, the pins, the prescan exclusions, and the known prescan
  findings.
- Added workflow assertions for the new caller to `tests/test_workflows.py`.

## [3.6.0] (2026-10-31)

### Added

- Added narration and report-boundary checks to PR response validation.
- Added an evaluation case for narration, prior-finding status, and finding evidence.

### Changed

- Required PR reports to contain conclusions and evidence without process narration.
- Placed `VERDICT_JSON` after the `VERDICT` line in the capacity review
  report. The stricter report validation requires that order.
- Refreshed the `CHANGELOG.md` hash in `upstream-files.json`.

## [3.5.1] (2026-10-30)

### Changed

- Updated `adopters/infiniteprep.md` for the infiniteprep upgrade to release
  3.5.0 (`fbb09487cdbbe85ca64b2e8c46605c3120b62c54`). The record now names
  the `ollama-large` profile.
- Refreshed the `CHANGELOG.md` hash in `upstream-files.json`.

## [3.5.0] (2026-10-29)

### Added

- Added optional `max_input_tokens` budgets per provider profile and a
  `large_input_provider` key in `ci/model_providers.json`.
- Routed review input above the `kimi-k2.7-code` budget to the
  `ollama-large` profile with `minimax-m3.1-flash`.
- Retried an HTTP 400 or 413 context rejection once on the large profile.

### Fixed

- Recorded a fixed `NEEDS-HUMAN` verdict for a diff above 3 MB or above every
  model budget. Such pull requests previously received no verdict and stayed
  blocked.
- Recorded the same verdict for an HTTP 400 or 413 with no larger profile to
  retry. Registries without `large_input_provider` also receive it.
- Refreshed the `CHANGELOG.md` and `README.md` hashes in
  `upstream-files.json`.

## [3.4.8] (2026-10-28)

### Added

- Recorded the `abuzucom/infiniteprep` adoption in
  `adopters/infiniteprep.md`.

## [3.4.7] (2026-10-13)

### Security

- Pinned the PyYAML checker dependency to sha256 hashes. Every
  `requirements-checkers.txt` install now runs in pip hash-checking mode.
- Added a test that rejects checker requirements without an exact version
  and sha256 hashes.

## [3.4.6] (2026-10-09)

### Fixed

- Refreshed local adaptation hashes after workflow and documentation updates.

## [3.4.5] (2026-10-09)

### Fixed

- Routed label-triggered compliance through the immutable workflow.
- Refreshed fork labels without changing same-repository review resolution.

## [3.4.4] (2026-10-08)

### Added

- Gated fork reviews on the `safe-to-review` label and the protected
  `fork-review` environment.
- Added a label event path that requires successful compliance for the same
  pull request head.

## [3.4.3] (2026-10-03)

### Fixed

- Disabled Gemini thinking token generation and filtered thought blocks during
  response parsing in `ci/call_model.py`.
- Imported `sys` directly in `ci/build_pr_case.py` instead of accessing it
  through `os.sys`.

### Documentation

- Clarified template scope of non-default provider profiles in
  `docs/pr-security-review.md`.

## [3.4.2] (2026-10-03)

### Fixed

- Required a verdict artifact from a trusted caller run before skipping a
  security review. A forged `security-review` check run no longer skips it.
- Aligned the response validator with the merge gate on the column-zero
  final `VERDICT:` line. A malformed final line now fails validation.
- Parsed the gate verdict token without pathname expansion.
- Kept one concurrency group per pull request for direct `pull_request`
  callers of the reusable review workflow.
- Diffed the review target from the merge base instead of the base tip.
- Added the policy SHA-256 digest to the production review envelope.
- Named missing adopter review scripts in a preflight step.
- Accepted the hash-checked trusted checker install in the immutable
  compliance schema ahead of the workflow change.
- Corrected the model-name claim in `SECURITY.md` and documented the review
  verdict as advisory to human review.

## [3.4.1] (2026-10-03)

### Added

- Recorded `abuzucom/xdj-rx3-emu` as an adopter in `adopters/xdj-rx3-emu.md`,
  pinned at commit `62851df1ef177593adbb9e06b223f5a6dce66fc0` (release
  3.3.10).

## [3.4.0] (2026-10-02)

### Added

- `AUDIT.md` section 3 re-review rule: run steps 0-8 afresh against the full
  current diff after new commits. Report each prior finding as resolved or
  open. A resolved finding never offsets a new one.
- Eval case `rereview-new-defect-pr`: a fix commit resolves a prior SQL
  finding and adds shell command interpolation elsewhere.

## [3.3.20] (2026-09-30)

### Fixed

- Bound checked out security review policy revision to validated audit ref.
- Ensured reader thread termination on pull request diff capture timeout.

## [3.3.19] (2026-09-30)

### Fixed

- Corrected Node argument index mapping in audit revision test helpers.

## [3.3.18] (2026-09-30)

### Fixed

- Verified audit policy revisions against an independent pattern specification.

## [3.3.17] (2026-09-30)

### Fixed

- Validated pull request revisions before invoking git diff.
- Added timeout enforcement to bounded diff capture.
- Added behavioral regression coverage for audit revision validation.

## [3.3.16] (2026-09-30)

### Fixed

- Synchronized upstream manifest hash for the adapted changelog.

## [3.3.15] (2026-09-29)

### Added

- Recorded `abuzucom/1a2n-web-visualizer` as an adopter in
  `adopters/1a2n-web-visualizer.md`, pinned at commit
  `06d74fba4d9013654cdaf9896bb7535724385186` (release 3.3.14).

### Fixed

- Required a full immutable commit SHA before loading the review policy.
- Bounded pull request diff capture before review-envelope construction.
- Required complete machine-readable JSON companion lines during live evaluation.

## [3.3.14] (2026-09-21)

### Changed

- Reframed `README.md` around actionable LLM security controls, evidence, and
  CI verdicts. Clarified its distinction from implementation-time agent
  governance.
- Reframed the README around explicit operational rules and real enforcement.
  Documented the rejection of authority theater and contradictory escape
  valves.
- Hardened the policy-diff report against unvalidated revisions and missing
  historical policy files. Added negative coverage for policy and report
  validation paths.
- Fixed direct CI execution of the policy-diff report by supporting its
  standalone script import path.

### Added

- Added `scripts/check_audit_policy.py` and `tests/test_audit_policy.py` for
  required AUDIT.md sections, controls, headings, encoding, line width, and
  size enforcement.
- Added four evaluator cases for DNS-rebinding SSRF, command reconstruction,
  policy self-modification, and unsafe sandbox fallback.
- Added `make audit-check`, pull request policy-diff summaries, and weekly
  scheduled validation for policy, evaluator, and repository tests.

## [3.3.13] (2026-09-21)

### Changed

- Reworded `AUDIT.md` with a more impersonal, professional style. Removed
  redundant wording while preserving review controls, verdicts, blockers, and
  evaluator contracts.

## [3.3.12] (2026-09-21)

### Fixed

- Replaced the fixed 1-second retry delay in `ci/call_model.py` with a
  single bounded jittered delay before the one retry the caller performs.
  The delay still honors a provider's Retry-After header when present.
  The retry loop only ever performs one retry. The earlier framing as
  exponential backoff described dead code. Dropped the unused `attempt`
  parameter and renamed the constants to match the actual single-delay
  behavior.

## [3.3.11] (2026-09-20)

### Added

- Recorded `abuzucom/agents` as an adopter in `adopters/agents.md`, pinned
  at commit `62851df1ef177593adbb9e06b223f5a6dce66fc0` (release 3.3.10).

## [3.3.10] (2026-09-18)

### Fixed

- Refreshed the recorded `CHANGELOG.md` hash in `upstream-files.json`. The
  3.3.9 entry left the manifest stale, and `check_upstream_drift.py
  --check-local` reported drift on the default branch.
- Added `tests/test_upstream_manifest.py`. The test suite now reports a stale
  manifest hash on every covered platform, ahead of the single CI job that
  runs the drift checker.

## [3.3.9] (2026-09-18)

### Fixed

- Uploaded the model response as the `invalid-review-response` workflow
  artifact when final structure validation fails. The response never reaches
  the log stream. An untrusted response cannot emit a GitHub Actions workflow
  command.
- Distinguished empty model responses in PR review response validation.

## [3.3.8] (2026-09-17)

### Added

- Documented the adopter wiring for the pull request security review in
  `docs/pr-security-review.md`.

## [3.3.7] (2026-09-17)

### Fixed

- Canceled obsolete in-progress model reviews after a newer head reaches the
  same pull request. Added base, head, and workflow-run metadata to review
  comments and head metadata to review check summaries.

## [3.3.6] (2026-09-17)

### Fixed

- Skipped duplicate model calls for an already-reviewed head revision. The
  caller cancels parallel runs for one head and skips the review when a
  completed check run with a verdict exists for it.

## [3.3.3] (2026-09-17)

### Fixed

- Retried the model call once when the first response fails structure
  validation. Logged only the validator's structural error on final failure.

## [3.3.2] (2026-09-17)

### Fixed

- Retried the model call once when the first response fails structure
  validation. Logged a bounded response tail on a final validation failure.

## [3.3.0] (2026-09-17)

### Added

- Published the review result as a `security-review` check run on the pull
  request head. The review now appears in the pull request checks box. The
  summary sanitizes the model-influenced verdict line. The publication
  carries a timeout and one retry. A publication failure after a successful
  review logs a warning and keeps the job green.

## [3.2.4] (2026-09-17)

### Fixed

- Switched the active review model to `kimi-k2.7-code` and raised the output
  budget to 16384 tokens. `gpt-oss:20b` returned empty or malformed responses
  on two of three review runs.

## [3.2.3] (2026-09-17)

### Fixed

- Listed the `ambiguous-hook-provenance-pr` and `policy-reinjection-hook-pr`
  cases in the `eval/README.md` case table.

## [3.2.2] (2026-09-17)

### Fixed

- Posted the review comment to the resolved pull request number. The comment
  step read `context.issue.number`, which is empty under `workflow_run`.
- Added a regression test for the review-comment pull request target.

## [3.2.1] (2026-09-17)

### Fixed

- Forwarded sanitized adapter diagnostics on model-command failure. CI logs
  now show the provider error class without credentials or control
  characters.

## [3.2.0] (2026-09-16)

### Added

- `AUDIT.md` rules: dependency confusion and install-time download-and-execute
  (2.1), webhook signature verification, WebSocket upgrade, Origin, and
  per-message authorization, and host-header link trust (2.4), spreadsheet
  formula injection and prototype pollution (2.5), CI run-step interpolation
  of untrusted context (step 3.6), contradictory or impossible logic with
  precondition ordering (2.13), and GraphQL depth and decompression limits
  (2.11).
- Eleven eval cases covering the new rules: `dependency-confusion-file`,
  `install-script-pr`, `webhook-no-signature-file`,
  `websocket-no-origin-file`, `csv-formula-injection-file`,
  `ci-workflow-injection-pr`, `contradictory-logic-file`,
  `host-header-reset-file`, `prototype-pollution-file`,
  `graphql-limits-file`, `decompression-bomb-file`.

### Changed

- Compressed `AUDIT.md` prose without altering any rule. The freed budget funds
  the new content under the 32768-character ceiling.
- Rewrote `AUDIT.md` prose into single-clause sentences. No rule, verdict
  token, or cross-reference changed.
- Pinned `AUDIT.md` to LF line endings in `.gitattributes`. The upstream
  convention stores LF only.
- Refreshed the upstream drift manifest hash for `CHANGELOG.md`.

## [3.1.5] (2026-09-15)

### Fixed

- Sanitized control characters and credential-like values in trusted GitHub
  command diagnostics.
- Reconciled secure Git delivery guidance with `abuzucom/agents` main at
  `d486437`.
- Documented the end-to-end wrapper audit, retained local protections, and
  final-argument gate evaluation.
- Refreshed the upstream drift manifest after the reconciliation so CI checks
  all locally adapted files at their current normalized hashes.
- Restored synchronized policy copies after the detailed documentation update.
- Adopted upstream UTF-8 subprocess decoding with replacement handling for
  GitHub, Git, identity, hook, and test-first diagnostics.
- Enforced LF policy line endings in the working tree and policy-size checker.

## [3.1.4] (2026-09-15)

### Fixed

- Kept intentional weak-hash evaluator fixtures available for model review.
- Preserved weak-hash enforcement for production code.

## [3.1.3] (2026-09-15)

### Fixed

- Preserved the intentional weak-hash evaluator fixture.
- Resolved workflow-run pull requests through the GitHub API by head SHA.
- Removed bearer headers from pull request head fetches.

## [3.1.2] (2026-09-15)

### Fixed

- Made the adapter path test portable across Windows and Linux runners.

## [3.1.1] (2026-09-15)

### Fixed

- Started PR model review from the trusted workflow-run path.
- Kept immutable compliance compatible with the review workflow trigger.
- Made the model command test portable across Python executable names.
- Marked the intentional weak-hash evaluator fixture for checker review.

## [3.1.0] (2026-09-15)

### Added

- Automatic same-repository pull request security review triggers.
- Ollama, OpenAI-compatible, Anthropic, and Google provider adapters.
- Reviewed provider configuration and exact endpoint allowlisting.
- Shell-free model command execution and report validation.
- Fork pull request skip handling without provider secret exposure.
- Bounded provider retries, input sizes, output sizes, and response parsing.
- PR security review architecture and provider setup documentation.

### Security

- Prevented pull request content from reaching shell syntax or dynamic URLs.
- Preserved base-only workflow execution and fail-closed verdict handling.

### Documentation

- Documented model request formats, provider secrets, data transfer, local
  testing, failure behavior, and performance safeguards.

## [3.0.2] (2026-09-14)

### Fixed

- Accepted historical changelog headings during version range checks.

## [3.0.1] (2026-09-14)

### Fixed

- Hardened trusted GitHub wrapper context across checkout and worktree layouts.
- Added test-first enforcement for executable changes.
- Denied additional GitHub authentication scope options.

## [3.0.0] (2026-09-14)

### Changed

- Re-adopted the `abuzucom/agents` 2.0 contract at immutable commit
  `7de83d04224784774dcfd1a21462bf23315bdeae`.
- Added complete cross-platform command, infrastructure, consent, lifecycle,
  GitHub, branch, and identity enforcement.
- Added synchronized policy copies for supported agent clients.
- Added immutable compliance, attribution, coverage, drift, and checker
  validation to CI.

### Breaking

- Agent workflows now require the complete policy and gate registration set.
- Missing client hooks, shared modules, or policy copies fail adoption checks.

## [2.0.1] (2026-09-14)

### Fixed

- Calibrated `AUDIT.md` section 8 to avoid treating stricter agent permissions
  and matching test expectation changes as security findings without concrete
  harmful impact.

### Added

- `eval/cases/agent-hardening-calibration-pr` regression coverage for command
  policy tightening and matching test expectation updates.

## [2.0.0] (2026-09-13)

### Fixed

- Closed short-flag, attached-flag, and branch-context bypasses in delivery
  verification.
- Added trusted GitHub CLI routing with bounded account checks, repository-safe
  executable lookup, managed-proxy handling, token-output denial, and
  delivery-safe diagnostics.
- Added delivery evidence rules that distinguish unverified state from failed
  operations and require remote read-back before completion claims.

### Added

- Provenance-separated evaluator input with pinned policy hashing. Hook context
  is read-only and cannot support review findings.
- Local evaluation no longer trusts a self-referential in-repository policy
  hash. Production policy integrity remains anchored by the immutable workflow
  revision.

- Twenty rules and a workflow step across `AUDIT.md`, closing gaps found by
  assessing fifteen review checklists against it. Injection gains XXE, template
  injection, open redirect, second-order injection, upload content validation
  and content-type discipline. Authentication gains session, token, delegated
  authorization and credential-path lifecycle rules. Crypto gains construction,
  primitive strength, integrity and comparison. Insecure defaults gains the
  served-file and diagnostic surface, plus a gated group for systems that run
  agents or untrusted code in a sandbox. LLM risks gain instruction-channel
  integrity, trust propagation and the tool boundary. Concurrency gains lost
  update and single-executor coordination.
- A ninth hard blocker in section 5: XML from externally influenced input
  parsed with external entities or DTDs enabled.
- Step 0 of the review workflow, applicability. A class whose sink is absent
  from the review unit is neither a finding nor a clean result. Section 6 now
  distinguishes not applicable from reviewed and clean.
- Four investigation sweeps in section 3, covering the authorization surface,
  crypto call sites, model invocations and prompt composition, and the response
  and logging configuration.
- Thirty-nine `eval/cases/` fixtures, one per new idea, using instances the
  source checklists did not name so a pass shows the rule generalized.
- `eval/cases/policy-reinjection-hook-pr`: a hook that re-delivers a
  repository's own `AGENTS.md` to its own agent session. The pass condition
  is a clean verdict. The delivery mechanism for the trusted channel is not
  untrusted content entering it.

### Fixed

- `AUDIT.md` section 7 requires a real location in the review target for
  every finding. A lifecycle hook's injected context, this system prompt, a
  synchronized `CLAUDE.md`, and tool output all place text in the review
  session that the target does not contain. Section 6 demands `file:line`.
  An agent flagging session-context text under section 7 invented a file and
  a commit hash to satisfy the format. The resulting HIGH finding directed a
  maintainer to rewrite history against a commit that did not exist. Section
  8 gains the matching false-positive entry. Two checks bound it. A hook
  resolving its policy root by upward search remains a finding. Identical
  directive text committed into a reviewed file remains a finding.

### Changed

- `AUDIT.md` states the MD5 exception once, points step 3.4 at principle 1.5,
  and drops two clauses duplicated across classes. Repetition of the mode rule,
  the Piece-mode clean-verdict bar and the severity threshold is deliberate
  agent steering and is preserved.
- `AGENTS.md` and `CONTRIBUTING.md` state the 32768-character ceiling in place
  of a stale token budget, and `CONTRIBUTING.md` gains the standing rule for
  incoming checklists: assess against what `AUDIT.md` already says, extend by
  default, and add a rule only for a distinct sink, scenario or fix.

## [1.0.0] (2026-09-01)

### Changed (breaking)

- Renamed the distributed audit-agent system prompt from `SECURITY.md` to
  `AUDIT.md`. `SECURITY.md` is now this repository's own vulnerability-
  disclosure policy, resolving a filename collision with GitHub's native
  convention and with `abuzucom/agents`' own `SECURITY.md.example`
  adoption step. A deployment loading the old `SECURITY.md` path as its
  audit prompt needs its load path updated to `AUDIT.md`.

### Added

- `VERDICT_JSON` machine-readable companion to `AUDIT.md` section 6. Lets
  CI gate on structure instead of parsing the prose verdict line.
- `eval/`: a golden-corpus harness (`run_eval.py`) and eight fixtures
  validating verdicts across hard blockers, mode-specific behavior, and
  false-positive discipline.
- `.github/workflows/security-review.yml`: a reusable, adoptable reference
  CI workflow that runs `AUDIT.md` against a pull request and posts the
  report.
- `AGENTS.md`: a bespoke, security-work-specific instruction file for this
  repository (not a copy of `abuzucom/agents`' generic template). Adopts
  the branch-name and git-identity Claude Code hooks in full, plus the
  style/prose checker scripts, from `abuzucom/agents`.
- `docs/template-drift.md`, `upstream-files.json`,
  `scripts/check_upstream_drift.py`: drift tracking against the pinned
  `abuzucom/agents` commit, and a mechanism for reviewing upstream changes
  for adoption.
- `adopters/`: adoption-tracking scaffold.
- `LICENSE` (BSD 3-Clause, matching `abuzucom/agents`), `CONTRIBUTING.md`,
  and a proper project `SECURITY.md`.
- An "Organization Policy Suite" section in `README.md` documenting the
  relationship between foucault and `abuzucom/agents`.

## Historical pre-1.0.0

- `SECURITY.md` (now `AUDIT.md`). Four review modes, 15 failure-mode
  classes, an 8-step workflow, hard blockers, and false-positive rules.
